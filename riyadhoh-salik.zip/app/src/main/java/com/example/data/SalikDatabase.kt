package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        DzikirEntity::class,
        RiyadhahEntity::class,
        JournalEntity::class,
        KalamEntity::class,
        AdabEntity::class,
        PedomanEntity::class,
        QuranSurahEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class SalikDatabase : RoomDatabase() {
    abstract val salikDao: SalikDao

    companion object {
        @Volatile
        private var INSTANCE: SalikDatabase? = null

        fun getDatabase(context: Context): SalikDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SalikDatabase::class.java,
                    "salik_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
