package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class SalikRepository(private val dao: SalikDao) {

    val allDzikir: Flow<List<DzikirEntity>> = dao.getAllDzikirFlow()
    val allJournals: Flow<List<JournalEntity>> = dao.getAllJournalsFlow()
    val allKalam: Flow<List<KalamEntity>> = dao.getAllKalamFlow()
    val allAdab: Flow<List<AdabEntity>> = dao.getAllAdabFlow()
    val allPedoman: Flow<List<PedomanEntity>> = dao.getAllPedomanFlow()
    val allQuran: Flow<List<QuranSurahEntity>> = dao.getAllQuranFlow()

    fun getRiyadhahByDate(date: String): Flow<List<RiyadhahEntity>> = dao.getRiyadhahByDateFlow(date)

    suspend fun checkAndPrepopulateDzikir() = withContext(Dispatchers.IO) {
        val existing = dao.getAllDzikir()
        if (existing.isEmpty()) {
            val defaultDzikir = listOf(
                DzikirEntity(name = "Membaca Istighfar (Astaghfirullah)", category = "Harian", target = 100, currentCount = 0),
                DzikirEntity(name = "Membaca Sholawat Nabi", category = "Harian", target = 100, currentCount = 0),
                DzikirEntity(name = "Tasbih, Tahmid, Takbir (Subhanallah, Alhamdulillah, Allahu Akbar)", category = "Harian", target = 99, currentCount = 0),
                DzikirEntity(name = "Kalimat Tauhid (La ilaha illallah)", category = "Harian", target = 100, currentCount = 0),
                DzikirEntity(name = "Dzikir Pagi: Subhanallahi wa bihamdih", category = "Pagi", target = 100, currentCount = 0),
                DzikirEntity(name = "Dzikir Pagi: La ilaha illallahu wahdahu la syarika lah...", category = "Pagi", target = 100, currentCount = 0),
                DzikirEntity(name = "Dzikir Petang: Sayyidul Istighfar", category = "Petang", target = 1, currentCount = 0),
                DzikirEntity(name = "Dzikir Petang: Astaghfirullah al-'Adzim", category = "Petang", target = 100, currentCount = 0),
                DzikirEntity(
                    name = "Ratib Al-Haddad",
                    category = "Wirid",
                    target = 1,
                    currentCount = 0,
                    bacaan = "بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ. اَلْحَمْدُ للهِ رَبِّ الْعَالَمِيْنَ. الرَّحْمٰنِ الرَّحِيْمِ. مٰلِكِ يَوْمِ الدِّيْنِ. إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِيْنُ. اِهْدِنَا الصِّرَاطَ الْمُسْتَقِيْمَ...",
                    wirid = "Ratib Agung",
                    keterangan = "Amalan perlindungan diri, ketenangan spiritual, dan pembuka pintu rezeki lahir batin. Dibaca selepas Maghrib atau Isya.",
                    tarekat = "Alawiyah (Ba'alawi)"
                ),
                DzikirEntity(
                    name = "Dzikir Jahar & Khafi",
                    category = "Wirid",
                    target = 165,
                    currentCount = 0,
                    bacaan = "لا إِلهَ إِلاَّ اللهُ (Lafadz Jahar) & الله... الله (Dzikir Sirr/Qolbi)",
                    wirid = "Talqin Thariqah",
                    keterangan = "Menyucikan kotoran & karat raga hati (qolb). Dipraktikkan sehabis shalat fardhu secara tawajuh.",
                    tarekat = "Qadiriyah wa Naqsyabandiyah (TQN)"
                ),
                DzikirEntity(
                    name = "Sholawat Fatih",
                    category = "Wirid",
                    target = 11,
                    currentCount = 0,
                    bacaan = "اللَّهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ الْفَاتِحِ لِمَا أُغْلِقَ وَالْخَاتِمِ لِمَا سَبَقَ نَاصِرِ الْحَقِّ بِالْحَقِّ وَالْهَادِي إِلَى صِرَاطِكَ الْمُسْتَقِيمِ وَعَلَى آلِهِ حَقَّ قَدْرِهِ وَمِقْدَارِهِ الْعَظِيمِ",
                    wirid = "Sholawat Pembuka",
                    keterangan = "Membuka kebuntuan rahmat, penenang batin gundah, dan wasilah pengikat rindu kepada Baginda Rasulullah SAW.",
                    tarekat = "Tijaniyah"
                ),
                DzikirEntity(name = "Dua Yunus (La ilaha illa Anta subhanaka inni kuntu minadzolimin)", category = "Harian", target = 100, currentCount = 0)
            )
            dao.insertAllDzikir(defaultDzikir)
        }
    }

    suspend fun checkAndPrepopulateRiyadhah(date: String) = withContext(Dispatchers.IO) {
        val existing = dao.getRiyadhahByDate(date)
        if (existing.isEmpty()) {
            val defaultRiyadhah = listOf(
                RiyadhahEntity(title = "Sholat Tahajjud & Witir (Sholat Malam)", isCompleted = false, date = date),
                RiyadhahEntity(title = "Puasa Sunnah (Senin - Kamis / Daud / Ayyamul Bidh)", isCompleted = false, date = date),
                RiyadhahEntity(title = "Sedekah Subuh / Rahasia (Sedekah)", isCompleted = false, date = date),
                RiyadhahEntity(title = "Menjaga Lisan & Menghindari Ghibah", isCompleted = false, date = date),
                RiyadhahEntity(title = "Tilawah Qur'an (Minimal 1 Juz / Setengah Juz)", isCompleted = false, date = date),
                RiyadhahEntity(title = "Khalwat / Muraqabah (Refleksi Hati Selama 10 Menit)", isCompleted = false, date = date),
                RiyadhahEntity(title = "Sholat Dhuha (Minimal 2 Rakaat)", isCompleted = false, date = date)
            )
            dao.insertAllRiyadhah(defaultRiyadhah)
        }
    }

    suspend fun updateDzikirCount(id: Int, count: Int) = withContext(Dispatchers.IO) {
        dao.updateDzikirCount(id, count)
    }

    suspend fun resetDzikirByCategory(category: String) = withContext(Dispatchers.IO) {
        dao.resetDzikirByCategory(category)
    }

    suspend fun resetAllDzikir() = withContext(Dispatchers.IO) {
        dao.resetAllDzikirCount()
    }

    suspend fun addDzikir(dzikir: DzikirEntity) = withContext(Dispatchers.IO) {
        dao.insertDzikir(dzikir)
    }

    suspend fun deleteDzikir(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteDzikir(id)
    }

    suspend fun updateRiyadhahStatus(id: Int, isCompleted: Boolean) = withContext(Dispatchers.IO) {
        dao.updateRiyadhahStatus(id, isCompleted)
    }

    suspend fun addRiyadhah(riyadhah: RiyadhahEntity) = withContext(Dispatchers.IO) {
        dao.insertRiyadhah(riyadhah)
    }

    suspend fun addJournal(journal: JournalEntity) = withContext(Dispatchers.IO) {
        dao.insertJournal(journal)
    }

    suspend fun deleteJournal(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteJournal(id)
    }

    suspend fun checkAndPrepopulateKalam() = withContext(Dispatchers.IO) {
        val count = dao.getAllKalam().size
        if (count == 0) {
            val list = listOf(
                KalamEntity(author = "Ibnu Atha'illah Al-Iskandari", quote = "Kelemahan dan kemaksiatan yang membuahkan rasa hina dan fakir (butuh kepada Allah) itu jauh lebih baik daripada ketaatan yang membuahkan rasa mulia dan sombong.", category = "Ikhlas", source = "Al-Hikam"),
                KalamEntity(author = "Syeikh Abdul Qadir Al-Jailani", quote = "Janganlah kamu mencintai kedudukan duniawi, karena dunia menetap di tanganmu, bukan di hatimu. Letakkanlah dunia di tanganmu, akhirat di hatimu, dan Allah di dalam rahasiamu (Sirr).", category = "Zuhud", source = "Fathul Rabbani"),
                KalamEntity(author = "Imam Al-Ghazali", quote = "Nafsu itu seperti seorang budak; bila kau sayangi berlebihan ia melunjak, tapi bila kau sapih dan latih dengan disiplin keras, ia akan menuruti kesucian taqwa.", category = "Sabar", source = "Ihya Ulumuddin"),
                KalamEntity(author = "Syeikh Junaid Al-Baghdadi", quote = "Thariqah kami dipagari oleh sunnah murni Rasulullah. Barangsiapa yang tiada menghafal Al-Quran dan tiada mengkaji hadist, tiada boleh mendekat ke halaqah kami.", category = "Muraqabah", source = "Risalah Sufiyah"),
                KalamEntity(author = "Rabi'ah Al-Adawiyah", quote = "Ya Allah, jika aku menyembah-Mu karena takut neraka, bakarlah aku di dalamnya. Jika aku menyembah karena rindu surga, haramkan aku darinya. Namun jika karena Engkau semata, jangan halangi keindahan Wajah-Mu.", category = "Mahabbah", source = "Kalam Cinta Rabi'ah"),
                KalamEntity(author = "Ibnu Atha'illah Al-Iskandari", quote = "Bagaimana mungkin cermin hatimu bersinar terang, sementara bayangan keduniawian masih melengket di mukanya? Bagaimana mungkin kau melakukan suluk menuju Allah, sedangkan kau masih terbelenggu ego syahwat?", category = "Zuhud", source = "Al-Hikam")
            )
            dao.insertAllKalam(list)
        }
    }

    suspend fun checkAndPrepopulateAdab() = withContext(Dispatchers.IO) {
        val count = dao.getAllAdab().size
        if (count == 0) {
            val list = listOf(
                AdabEntity(
                    title = "Adab Kepada Sang Pencipta (Khaliq)",
                    desc = "Etika salik ketika bertatap rukun dengan Allah SWT dalam keseharian maupun kesunyian.",
                    pointsText = "Senantiasa menghidupkan rasa Muraqabah (merasa selalu diawasi oleh Allah SWT).\nIkhlas mutlak dalam berbuat ketaatan, tidak mengais perhatian makhluk.\nHusnuzhan (berprasangka sangat baik) terhadap segala rukun qadha dan qadar Allah.\nMenjunjung kejujuran batin (Sidiq) dalam setiap lisan doa serta kepatuhan syariat."
                ),
                AdabEntity(
                    title = "Adab Kepada Guru Ruhani (Syeikh/Mursyid)",
                    desc = "Toleransi dan penghormatan salik demi mengalirkan berkah bimbingan.",
                    pointsText = "Patuh dan berdamai dengan nasehat mursyid selagi tidak melanggar syariat agama.\nTidak menyelidiki atau mencari sandungan manusiawi pada diri Syeikh.\nMemelihara kesopanan lahir-batin serta berkhidmah dengan ikhlas.\nMandoakan keselamatan batiniah dan jasmani Syeikh di tiap sepertiga malam."
                ),
                AdabEntity(
                    title = "Adab Kepada Sesama Salik (Saudara Seperjalanan)",
                    desc = "Saling menopang dan mengasihi demi merajut ukhuwah ruhani.",
                    pointsText = "Mendahulukan kepentingan saudara (Itsar) di atas kepentingan ego pribadi.\nMenutupi aib serta cacat cela saudara seperjalanan rapat-rapat.\nSaling mengingatkan dan menasihati dengan santun diselimuti kelembutan cinta.\nBebas dari kedengkian, hasad, rebutan kemuliaan, atau ghibah."
                ),
                AdabEntity(
                    title = "Adab Kepada Diri Sendiri (Muamalah Batin)",
                    desc = "Disiplin salik dalam menata hawa nafsu dan kesucian akal.",
                    pointsText = "Menjaging kesucian wudhu di setiap waktu secara kontinyu (Daimul Wudhu).\nSenantiasa melatih lapar yang terkontrol (Siyam) dan membatasi bicara yang sia-sia.\nMata-matai niat di setiap perbuatan, menyingkirkan bibit Ujub dan Riya.\nMewajibkan hisab diri (Muhasabah) sebelum beristirahat tidur malam."
                )
            )
            dao.insertAllAdab(list)
        }
    }

    suspend fun checkAndPrepopulatePedoman() = withContext(Dispatchers.IO) {
        val count = dao.getAllPedoman().size
        if (count == 0) {
            val list = listOf(
                PedomanEntity(
                    stepNo = 1,
                    name = "YAQZHAH & TAUBAT",
                    title = "Keterbangunan Jiwa (Yaqzhah)",
                    desc = "Fase awal di mana seorang hamba terbangun dari tidur kelalaian (ghafilah), menyadari dosa-dosa masa lalu, dan melakukan penyesalan murni (Taubat Nasuha).",
                    practicesText = "Istighfar minimal 100x setiap fajar\nMeninggalkan majelis maksiat & laghwi\nMenyelesaikan hak-hak bersalah antar manusia"
                ),
                PedomanEntity(
                    stepNo = 2,
                    name = "TAKHAL-LI (PEMBERSIHAN)",
                    title = "Pengosongan Hati (Takhalli)",
                    desc = "Suluk mengikis dan mengosongkan hati dari sifat-sifat tercela (Madzmumah) seperti dengki, takabur, riya, cinta dunia, serta keinginan dipuji makhluk.",
                    practicesText = "Muhasabah qolbu terjadwal\nLatihan diam dari berdebat kosong\nRiyadhah tidak pamer amalan saleh"
                ),
                PedomanEntity(
                    stepNo = 3,
                    name = "TAHAL-LI (PENGHISAN)",
                    title = "Penghiasan Batin (Tahalli)",
                    desc = "Fase mendekorasi ruang hati yang sudah bersih dengan sifat-sifat mulia (Mahmudah) seperti ikhlas, rida, syukur, tawakal, mahabbah, dan sabar.",
                    practicesText = "Dzikir dawam Pagi & Petang tanpa putus\nMembiasakan sedekah sirr (sembunyi)\nSenantiasa rida atas cobaan takdir"
                ),
                PedomanEntity(
                    stepNo = 4,
                    name = "TAJAL-LI & WUSUL",
                    title = "Pancaran Cahaya Divine (Tajalli)",
                    desc = "Masuk ke maqam kedekatan yang suci, di mana hijab batin tersingkap dan salik merasakan lezatnya kedamaian batin bersanding Ridha Ilahi.",
                    practicesText = "Sholat tahajjud & munajat khusyuk\nDzikir Sirr (dalam kalbu terdalam)\nSenantiasa Muraqabah di setiap hembusan"
                )
            )
            dao.insertAllPedoman(list)
        }
    }

    suspend fun checkAndPrepopulateQuran() = withContext(Dispatchers.IO) {
        val count = dao.getAllQuran().size
        if (count == 0) {
            val list = listOf(
                QuranSurahEntity(
                    number = 1,
                    name = "Al-Fatihah (Pembuka)",
                    arabicName = "الفاتحة",
                    revelation = "Makkiyah",
                    versesCount = 7,
                    versesText = "1||الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ||Segala puji bagi Allah, Tuhan seluruh alam.\n2||الرَّحْمَنِ الرَّحِيمِ||Yang Maha Pengasih, Maha Penyayang.\n3||مَالِكِ يَوْمِ الدِّينِ||Pemilik hari pembalasan.\n4||إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ||Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami memohon pertolongan.\n5||اهدِنَا الصِّرَاطَ الْمُسْتَقِيمَ||Tunjukkanlah kami jalan yang lurus.\n6||صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ||(yaitu) jalan orang-orang yang telah Engkau beri nikmat kepadanya;\n7||غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلاَ الضَّالِّينَ||bukan (jalan) mereka yang dimurkai, dan bukan (pula jalan) mereka yang sesat."
                ),
                QuranSurahEntity(
                    number = 36,
                    name = "Yasin",
                    arabicName = "يس",
                    revelation = "Makkiyah",
                    versesCount = 5,
                    versesText = "1||يسَّ||Ya Sin.\n2||وَالْقُرْآنِ الْحَكِيمِ||Demi Al-Qur'an yang penuh hikmah,\n3||إِنَّكَ لَمِنَ الْمُرْسَلِينَ||sungguh, engkau (Muhammad) adalah salah seorang dari rasul-rasul,\n4||عَلَىٰ صِرَاطٍ مُسْتَقِيمٍ||(yang berada) di atas jalan yang lurus,\n5||تَنْزِيلَ الْعَزِيزِ الرَّحِيمِ||(sebagai wahyu) yang diturunkan oleh (Allah) Yang Mahaperkasa, Maha Penyayang,"
                ),
                QuranSurahEntity(
                    number = 55,
                    name = "Ar-Rahman",
                    arabicName = "الرحمن",
                    revelation = "Madaniyyah",
                    versesCount = 5,
                    versesText = "1||الرَّحْمَٰنُ||(Allah) Yang Maha Pengasih,\n2||عَلَّمَ الْقُرْآنَ||Yang telah mengajarkan Al-Qur'an.\n3||خَلَقَ الْإِنْسَانَ||Dia menciptakan manusia,\n4||عَلَّمَهُ الْبَيَانَ||Mengajarnya pandai berbicara.\n5||الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ||Matahari dan bulan beredar menurut perhitungan."
                ),
                QuranSurahEntity(
                    number = 56,
                    name = "Al-Waqi'ah",
                    arabicName = "الواقعة",
                    revelation = "Makkiyah",
                    versesCount = 4,
                    versesText = "1||إِذَا وَقَعَتِ الْوَاقِعَةُ||Apabila terjadi hari kiamat,\n2||لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ||terjadinya tidak dapat didustakan (disangkal).\n3||خَافِضَةٌ رَافِعَةٌ||(Kejadian itu) merendahkan (satu golongan) dan meninggikan (golongan yang lain),\n4||إِذَا رُجَّtِ الْأَرْضُ رَجًّا||apabila bumi digoncangkan sedahsyat-dahsyatnya,"
                ),
                QuranSurahEntity(
                    number = 67,
                    name = "Al-Mulk",
                    arabicName = "الملك",
                    revelation = "Makkiyah",
                    versesCount = 5,
                    versesText = "1||تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ||Mahasuci Allah yang menguasai (segala) kerajaan, dan Dia Mahakuasa atas segala sesuatu,\n2||الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ||Yang menciptakan mati dan hidup, untuk menguji kamu, siapa di antara kamu yang lebih baik amalnya. Dan Dia Mahaperkasa, Maha Pengampun,\n3||الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلَقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ||Yang menciptakan tujuh langit berlapis-lapis. Tidak akan kamu lihat sesuatu yang tidak seimbang pada ciptaan (Allah) Yang Maha Pengasih. Maka lihatlah sekali lagi, adakah kamu lihat sesuatu yang cacat?\n4||ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ||Kemudian ulangi pandanganmu dua kali lagi, niscaya pandanganmu akan kembali kepadamu tanpa menemukan cacat dan ia dalam keadaan letih.\n5||وَلَقَدْ زَيَّنَّa السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ||Dan sungguh, Telah Kami hiasi langit yang dekat dengan pelita-pelita, dan Kami jadikan pelita-pelita itu penyembur syaitan..."
                ),
                QuranSurahEntity(
                    number = 112,
                    name = "Al-Ikhlas (Keesaan)",
                    arabicName = "الإخلاص",
                    revelation = "Makkiyah",
                    versesCount = 4,
                    versesText = "1||قُلْ هُوَ اللَّهُ أَحَدٌ||Katakanlah (Muhammad), \"Dialah Allah, Yang Maha Esa.\n2||اللَّهُ الصَّمَدُ||Allah tempat meminta segala sesuatu.\n3||لَمْ يَلِدْ وَلَمْ يُولَدْ||Dia tidak beranak dan tidak pula diperanakkan,\n4||وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ||dan tidak ada sesuatu yang setara dengan Dia.\""
                )
            )
            dao.insertAllQuran(list)
        }
    }

    suspend fun addKalam(kalam: KalamEntity) = withContext(Dispatchers.IO) {
        dao.insertKalam(kalam)
    }

    suspend fun deleteKalam(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteKalam(id)
    }

    suspend fun addAdab(adab: AdabEntity) = withContext(Dispatchers.IO) {
        dao.insertAdab(adab)
    }

    suspend fun deleteAdab(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteAdab(id)
    }

    suspend fun addPedoman(pedoman: PedomanEntity) = withContext(Dispatchers.IO) {
        dao.insertPedoman(pedoman)
    }

    suspend fun deletePedoman(id: Int) = withContext(Dispatchers.IO) {
        dao.deletePedoman(id)
    }

    suspend fun addQuran(quran: QuranSurahEntity) = withContext(Dispatchers.IO) {
        dao.insertQuran(quran)
    }

    suspend fun deleteQuran(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteQuran(id)
    }
}
