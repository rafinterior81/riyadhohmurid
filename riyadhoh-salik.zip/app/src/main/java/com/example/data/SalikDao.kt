package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SalikDao {
    // Dzikir queries
    @Query("SELECT * FROM dzikir_table ORDER BY id ASC")
    fun getAllDzikirFlow(): Flow<List<DzikirEntity>>

    @Query("SELECT * FROM dzikir_table ORDER BY id ASC")
    suspend fun getAllDzikir(): List<DzikirEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDzikir(dzikir: DzikirEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllDzikir(dzikirList: List<DzikirEntity>)

    @Query("UPDATE dzikir_table SET currentCount = :count, lastUpdated = :timestamp WHERE id = :id")
    suspend fun updateDzikirCount(id: Int, count: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE dzikir_table SET currentCount = 0 WHERE category = :category")
    suspend fun resetDzikirByCategory(category: String)

    @Query("UPDATE dzikir_table SET currentCount = 0")
    suspend fun resetAllDzikirCount()

    @Query("DELETE FROM dzikir_table WHERE id = :id")
    suspend fun deleteDzikir(id: Int)

    // Riyadhah queries
    @Query("SELECT * FROM riyadhah_table WHERE date = :date")
    fun getRiyadhahByDateFlow(date: String): Flow<List<RiyadhahEntity>>

    @Query("SELECT * FROM riyadhah_table WHERE date = :date")
    suspend fun getRiyadhahByDate(date: String): List<RiyadhahEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRiyadhah(riyadhah: RiyadhahEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllRiyadhah(riyadhahList: List<RiyadhahEntity>)

    @Query("UPDATE riyadhah_table SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun updateRiyadhahStatus(id: Int, isCompleted: Boolean)

    // Journal queries
    @Query("SELECT * FROM journal_table ORDER BY date DESC")
    fun getAllJournalsFlow(): Flow<List<JournalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournal(journal: JournalEntity)

    @Query("DELETE FROM journal_table WHERE id = :id")
    suspend fun deleteJournal(id: Int)

    // Kalam queries
    @Query("SELECT * FROM kalam_table ORDER BY id ASC")
    fun getAllKalamFlow(): Flow<List<KalamEntity>>

    @Query("SELECT * FROM kalam_table ORDER BY id ASC")
    suspend fun getAllKalam(): List<KalamEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKalam(kalam: KalamEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllKalam(kalamList: List<KalamEntity>)

    @Query("DELETE FROM kalam_table WHERE id = :id")
    suspend fun deleteKalam(id: Int)

    // Adab queries
    @Query("SELECT * FROM adab_table ORDER BY id ASC")
    fun getAllAdabFlow(): Flow<List<AdabEntity>>

    @Query("SELECT * FROM adab_table ORDER BY id ASC")
    suspend fun getAllAdab(): List<AdabEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdab(adab: AdabEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllAdab(adabList: List<AdabEntity>)

    @Query("DELETE FROM adab_table WHERE id = :id")
    suspend fun deleteAdab(id: Int)

    // Pedoman queries
    @Query("SELECT * FROM pedoman_table ORDER BY stepNo ASC, id ASC")
    fun getAllPedomanFlow(): Flow<List<PedomanEntity>>

    @Query("SELECT * FROM pedoman_table ORDER BY stepNo ASC, id ASC")
    suspend fun getAllPedoman(): List<PedomanEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPedoman(pedoman: PedomanEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllPedoman(pedomanList: List<PedomanEntity>)

    @Query("DELETE FROM pedoman_table WHERE id = :id")
    suspend fun deletePedoman(id: Int)

    // Quran queries
    @Query("SELECT * FROM quran_table ORDER BY number ASC")
    fun getAllQuranFlow(): Flow<List<QuranSurahEntity>>

    @Query("SELECT * FROM quran_table ORDER BY number ASC")
    suspend fun getAllQuran(): List<QuranSurahEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuran(quran: QuranSurahEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllQuran(quranList: List<QuranSurahEntity>)

    @Query("DELETE FROM quran_table WHERE id = :id")
    suspend fun deleteQuran(id: Int)
}
