package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dzikir_table")
data class DzikirEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,
    val target: Int,
    val currentCount: Int,
    val lastUpdated: Long = System.currentTimeMillis(),
    val bacaan: String = "",
    val wirid: String = "",
    val keterangan: String = "",
    val tarekat: String = ""
)

@Entity(tableName = "riyadhah_table")
data class RiyadhahEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val isCompleted: Boolean,
    val date: String // YYYY-MM-DD
)

@Entity(tableName = "journal_table")
data class JournalEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // YYYY-MM-DD
    val mood: String, // e.g. "Tenang", "Syukur", "Sabar", "Cemas", "Gelisah"
    val thoughts: String,
    val heartState: String, // e.g. "Ikhlas", "Syukur", "Sabar", "Wara", "Muraqabah"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "kalam_table")
data class KalamEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val author: String,
    val quote: String,
    val category: String,
    val source: String
)

@Entity(tableName = "adab_table")
data class AdabEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val desc: String,
    val pointsText: String // Points separated by newline (\n)
)

@Entity(tableName = "pedoman_table")
data class PedomanEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val stepNo: Int,
    val name: String,
    val title: String,
    val desc: String,
    val practicesText: String // Practices separated by newline (\n)
)

@Entity(tableName = "quran_table")
data class QuranSurahEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val number: Int,
    val name: String,
    val arabicName: String,
    val revelation: String,
    val versesCount: Int,
    val versesText: String // Store verses formatted of schema: "number||arabic||translation\n..."
)

