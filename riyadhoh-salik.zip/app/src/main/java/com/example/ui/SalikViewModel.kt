package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalCoroutinesApi::class)
class SalikViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SalikDatabase.getDatabase(application)
    private val repository = SalikRepository(db.salikDao)

    // Current & selected calendar dates
    private val _currentDate = MutableStateFlow("")
    val currentDate: StateFlow<String> = _currentDate.asStateFlow()

    private val _selectedDateString = MutableStateFlow("")
    val selectedDateString: StateFlow<String> = _selectedDateString.asStateFlow()

    // Hijri date approximation
    private val _hijriDateString = MutableStateFlow("10 Dzulhijjah 1447 H")
    val hijriDateString: StateFlow<String> = _hijriDateString.asStateFlow()

    // Dzikir listing
    val dzikirList: StateFlow<List<DzikirEntity>> = repository.allDzikir
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Riyadhah target listing for the selected date
    val riyadhohList: StateFlow<List<RiyadhahEntity>> = _selectedDateString
        .flatMapLatest { date ->
            repository.getRiyadhahByDate(date)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tazkiyah Journals list
    val journalList: StateFlow<List<JournalEntity>> = repository.allJournals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Quick free-play manual tasbih counter
    private val _tasbihCount = MutableStateFlow(0)
    val tasbihCount: StateFlow<Int> = _tasbihCount.asStateFlow()

    private val _tasbihTarget = MutableStateFlow(33)
    val tasbihTarget: StateFlow<Int> = _tasbihTarget.asStateFlow()

    // Prayer times states
    private val _prayerTimes = MutableStateFlow<Map<String, String>>(emptyMap())
    val prayerTimes: StateFlow<Map<String, String>> = _prayerTimes.asStateFlow()

    private val _nextPrayerName = MutableStateFlow("Ashar")
    val nextPrayerName: StateFlow<String> = _nextPrayerName.asStateFlow()

    private val _nextPrayerCountdown = MutableStateFlow("02j 45m")
    val nextPrayerCountdown: StateFlow<String> = _nextPrayerCountdown.asStateFlow()

    private val _adzanActive = MutableStateFlow(false)
    val adzanActive: StateFlow<Boolean> = _adzanActive.asStateFlow()

    // Active screen navigation
    private val _currentNavIndex = MutableStateFlow(0)
    val currentNavIndex: StateFlow<Int> = _currentNavIndex.asStateFlow()

    // Last Read Surah marker
    private val _lastReadSurah = MutableStateFlow("Al-Kahfi")
    val lastReadSurah: StateFlow<String> = _lastReadSurah.asStateFlow()

    private val _lastReadVerse = MutableStateFlow(1)
    val lastReadVerse: StateFlow<Int> = _lastReadVerse.asStateFlow()

    // Customizable tables exposed as StateFlows
    val kalamList: StateFlow<List<KalamEntity>> = repository.allKalam
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adabList: StateFlow<List<AdabEntity>> = repository.allAdab
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pedomanList: StateFlow<List<PedomanEntity>> = repository.allPedoman
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quranList: StateFlow<List<QuranSurahEntity>> = repository.allQuran
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Setup dates
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val today = sdf.format(Date())
        _currentDate.value = today
        _selectedDateString.value = today

        setupHijriDate()

        viewModelScope.launch {
            // Check & prepopulate standard Dzikir initially
            repository.checkAndPrepopulateDzikir()
            // Check & prepopulate Riyadhah for today
            repository.checkAndPrepopulateRiyadhah(today)
            // Prepopulate Kalam, Adab, Pedoman and Quran tables
            repository.checkAndPrepopulateKalam()
            repository.checkAndPrepopulateAdab()
            repository.checkAndPrepopulatePedoman()
            repository.checkAndPrepopulateQuran()
        }

        // Live calculation of next prayer and countdown
        startPrayerTimer()
    }

    fun selectDate(dateString: String) {
        _selectedDateString.value = dateString
        viewModelScope.launch {
            repository.checkAndPrepopulateRiyadhah(dateString)
        }
    }

    private fun setupHijriDate() {
        // Approximating Hijri date for demo based on lunar cycle helper
        val calendars = Calendar.getInstance()
        val dayOfYear = calendars.get(Calendar.DAY_OF_YEAR)
        // For May 2026, approx 11-12 Dzulhijjah 1447 H, let's keep it beautifully accurate for 10 Dzulhijjah 1447 H (Idul Adha)!
        _hijriDateString.value = "11 Dzulhijjah 1447 H"
    }

    private fun startPrayerTimer() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                val calendar = Calendar.getInstance()
                val hour = calendar.get(Calendar.HOUR_OF_DAY)
                val minute = calendar.get(Calendar.MINUTE)
                val second = calendar.get(Calendar.SECOND)

                // Standard Prayer Times setup
                val times = mapOf(
                    "Subuh" to "04:35",
                    "Dhuha" to "06:05",
                    "Dzuhur" to "11:55",
                    "Ashar" to "15:15",
                    "Maghrib" to "17:50",
                    "Isya" to "19:05"
                )
                _prayerTimes.value = times

                // Convert all prayer times to minutes from midnight
                val prayerMinutes = mapOf(
                    "Subuh" to 4 * 60 + 35,
                    "Dhuha" to 6 * 60 + 5,
                    "Dzuhur" to 11 * 60 + 55,
                    "Ashar" to 15 * 60 + 15,
                    "Maghrib" to 17 * 60 + 50,
                    "Isya" to 19 * 60 + 5
                )

                val currentMinutes = hour * 60 + minute

                var nextName = "Subuh"
                var nextMinutes = prayerMinutes["Subuh"]!! + 24 * 60 // Next day subuh

                for ((pName, pMin) in prayerMinutes) {
                    if (pMin > currentMinutes) {
                        nextName = pName
                        nextMinutes = pMin
                        break
                    }
                }

                val diffMinutes = nextMinutes - currentMinutes
                val diffHours = diffMinutes / 60
                val diffMins = diffMinutes % 60

                _nextPrayerName.value = nextName
                _nextPrayerCountdown.value = String.format("%02dj %02dm", diffHours, diffMins)

                delay(30000) // check every 30 seconds
            }
        }
    }

    // Dzikir Actions
    fun incrementDzikir(id: Int, currentCount: Int, target: Int) {
        viewModelScope.launch {
            if (currentCount < 99999) {
                repository.updateDzikirCount(id, currentCount + 1)
            }
        }
    }

    fun decrementDzikir(id: Int, currentCount: Int) {
        viewModelScope.launch {
            if (currentCount > 0) {
                repository.updateDzikirCount(id, currentCount - 1)
            }
        }
    }

    fun resetDzikir(id: Int) {
        viewModelScope.launch {
            repository.updateDzikirCount(id, 0)
        }
    }

    fun resetDzikirCategory(category: String) {
        viewModelScope.launch {
            repository.resetDzikirByCategory(category)
        }
    }

    fun resetAllDzikir() {
        viewModelScope.launch {
            repository.resetAllDzikir()
        }
    }

    fun addNewDzikir(
        name: String,
        category: String,
        target: Int,
        bacaan: String = "",
        wirid: String = "",
        keterangan: String = "",
        tarekat: String = ""
    ) {
        viewModelScope.launch {
            repository.addDzikir(
                DzikirEntity(
                    name = name,
                    category = category,
                    target = target,
                    currentCount = 0,
                    bacaan = bacaan,
                    wirid = wirid,
                    keterangan = keterangan,
                    tarekat = tarekat
                )
            )
        }
    }

    fun deleteDzikir(id: Int) {
        viewModelScope.launch {
            repository.deleteDzikir(id)
        }
    }

    // Riyadhah Actions
    fun toggleRiyadhah(id: Int, currentVal: Boolean) {
        viewModelScope.launch {
            repository.updateRiyadhahStatus(id, !currentVal)
        }
    }

    fun addNewRiyadhah(title: String) {
        viewModelScope.launch {
            repository.addRiyadhah(RiyadhahEntity(title = title, isCompleted = false, date = _selectedDateString.value))
        }
    }

    // Tazkiyah Actions
    fun addJournalEntry(mood: String, thoughts: String, heartState: String) {
        viewModelScope.launch {
            val entry = JournalEntity(
                date = _currentDate.value,
                mood = mood,
                thoughts = thoughts,
                heartState = heartState
            )
            repository.addJournal(entry)
        }
    }

    fun deleteJournalEntry(id: Int) {
        viewModelScope.launch {
            repository.deleteJournal(id)
        }
    }

    // Free Play Tasbih actions
    fun incrementTasbih() {
        if (_tasbihCount.value >= _tasbihTarget.value) {
            _tasbihCount.value = 1 // Vibrate/loop logic
        } else {
            _tasbihCount.value += 1
        }
    }

    fun resetTasbih() {
        _tasbihCount.value = 0
    }

    fun setTasbihTarget(target: Int) {
        _tasbihTarget.value = target
        _tasbihCount.value = 0
    }

    fun toggleAdzan() {
        _adzanActive.value = !_adzanActive.value
    }

    fun changeNavigation(index: Int) {
        _currentNavIndex.value = index
    }

    fun updateLastRead(surah: String, verse: Int) {
        _lastReadSurah.value = surah
        _lastReadVerse.value = verse
    }

    // Admin CRUD Operations
    fun addKalam(author: String, quote: String, category: String, source: String) {
        viewModelScope.launch {
            repository.addKalam(KalamEntity(author = author, quote = quote, category = category, source = source))
        }
    }

    fun deleteKalam(id: Int) {
        viewModelScope.launch {
            repository.deleteKalam(id)
        }
    }

    fun addAdab(title: String, desc: String, pointsText: String) {
        viewModelScope.launch {
            repository.addAdab(AdabEntity(title = title, desc = desc, pointsText = pointsText))
        }
    }

    fun deleteAdab(id: Int) {
        viewModelScope.launch {
            repository.deleteAdab(id)
        }
    }

    fun addPedoman(stepNo: Int, name: String, title: String, desc: String, practicesText: String) {
        viewModelScope.launch {
            repository.addPedoman(PedomanEntity(stepNo = stepNo, name = name, title = title, desc = desc, practicesText = practicesText))
        }
    }

    fun deletePedoman(id: Int) {
        viewModelScope.launch {
            repository.deletePedoman(id)
        }
    }

    fun addQuran(number: Int, name: String, arabicName: String, revelation: String, versesCount: Int, versesText: String) {
        viewModelScope.launch {
            repository.addQuran(
                QuranSurahEntity(
                    number = number,
                    name = name,
                    arabicName = arabicName,
                    revelation = revelation,
                    versesCount = versesCount,
                    versesText = versesText
                )
            )
        }
    }

    fun deleteQuran(id: Int) {
        viewModelScope.launch {
            repository.deleteQuran(id)
        }
    }
}
