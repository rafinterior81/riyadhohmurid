package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SalikViewModel
import com.example.ui.theme.*

@Composable
fun HomeScreen(viewModel: SalikViewModel, onNavigateToSection: (Int) -> Unit) {
    val context = LocalContext.current
    val hijriDate by viewModel.hijriDateString.collectAsState()
    val dzikirList by viewModel.dzikirList.collectAsState()
    val lastReadSurah by viewModel.lastReadSurah.collectAsState()
    
    val nextPrayerName by viewModel.nextPrayerName.collectAsState()
    val nextPrayerCountdown by viewModel.nextPrayerCountdown.collectAsState()
    val adzanActive by viewModel.adzanActive.collectAsState()

    // Calculate aggregations
    val totalDzikirCount = dzikirList.sumOf { it.currentCount }
    val totalDzikirTarget = dzikirList.sumOf { it.target }

    LaunchedEffect(adzanActive) {
        if (adzanActive) {
            Toast.makeText(context, "🔊 Adzan $nextPrayerName disimulasikan berkumandang... Allahu Akbar, Allahu Akbar!", Toast.LENGTH_LONG).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldDarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(18.dp)
            .testTag("home_screen_root")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SELAMAT DATANG",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFB4D2CD),
                        letterSpacing = 1.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Para penempuh jalan\n(Salik)",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = SoftWhite,
                        lineHeight = 32.sp
                    )
                )
            }

            // Hijri Date Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(IslamicAmber.copy(alpha = 0.15f))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = hijriDate.replace(" ", "\n"),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = IslamicAmber,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Spiritual Weather Card
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 18.dp)
                .testTag("spiritual_weather_card")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                EmeraldSurfaceCardGradientStart,
                                EmeraldSurfaceCardGradientEnd
                            )
                        )
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "CUACA SPIRITUAL HARI INI",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = IslamicAmber,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Hati",
                            tint = Color.Red,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Hati Tenang (Thuma'ninah)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SoftWhite
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "\"Ingatlah, hanya dengan mengingat Allah hati menjadi tenteram.\"",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SoftGray,
                            fontStyle = FontStyle.Italic,
                            lineHeight = 20.sp
                        )
                    )
                    Text(
                        text = "— Q.S. Ar-Ra'd: 28",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Next Prayer Time Card
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 18.dp)
                .testTag("prayer_time_card")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                EmeraldSurfaceCardGradientStart,
                                EmeraldSurfaceCardGradientEnd
                            )
                        )
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "Waktu Sholat Berikutnya",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SoftGray,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = nextPrayerName,
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = SoftWhite,
                                    fontSize = 40.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Countdown: $nextPrayerCountdown",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = NextAsharGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        // Adzan trigger button
                        Button(
                            onClick = { viewModel.toggleAdzan() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (adzanActive) IslamicAmber else EmeraldSecondary
                            ),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                            modifier = Modifier.testTag("adzan_button")
                        ) {
                            Icon(
                                imageVector = if (adzanActive) Icons.Outlined.NotificationsActive else Icons.Outlined.VolumeUp,
                                contentDescription = "Adzan Icon",
                                tint = EmeraldDarkBackground
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (adzanActive) "Matikan" else "Adzan",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDarkBackground
                                )
                            )
                        }
                    }
                }
            }
        }

        // Two Column Status Box (Dzikir & Tilawah)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Dzikir Progress Box
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSection(1) }
                    .testTag("quick_dzikir_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    EmeraldSurfaceCardGradientStart,
                                    EmeraldSurfaceCardGradientEnd
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Text(
                            text = "DZIKIR HARI INI",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = IslamicAmber,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "$totalDzikirCount",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SoftWhite
                            )
                        )
                        Text(
                            text = "Target: $totalDzikirTarget",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = SoftGray
                            )
                        )
                    }
                }
            }

            // Tilawah Progress Box
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSection(2) }
                    .testTag("quick_tilawah_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    EmeraldSurfaceCardGradientStart,
                                    EmeraldSurfaceCardGradientEnd
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Text(
                            text = "LAST READ QURAN",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = IslamicAmber,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = lastReadSurah,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SoftWhite
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "Tekan untuk Baca",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }
            }
        }

        // Halaqah Bimbingan Mursyid Navigation Hub on Home
        Text(
            text = "HALAQAH & BIMBINGAN RUHANI",
            style = MaterialTheme.typography.labelSmall.copy(
                color = IslamicAmber,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Guide Cards Matrix
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Kalam Mursyid Quick Entry
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSection(4) }
                    .testTag("kalam_mursyid_home_btn")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Kalam Mursyid",
                        tint = IslamicGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Kalam Mursyid",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                    )
                    Text(
                        "Mutiara Hikmah",
                        fontSize = 11.sp,
                        color = SoftGray
                    )
                }
            }

            // Tanya Jawab AI Quick Entry
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSection(4) }
                    .testTag("tanya_jawab_home_btn")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Tanya Jawab AI",
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Tanya Jawab AI",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                    )
                    Text(
                        "Konsultasi Qolbu",
                        fontSize = 11.sp,
                        color = SoftGray
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Adab Murid Quick Entry
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSection(4) }
                    .testTag("adab_murid_home_btn")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = "Adab Murid",
                        tint = NextAsharGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Adab Murid",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                    )
                    Text(
                        "Etika & Akhlaq",
                        fontSize = 11.sp,
                        color = SoftGray
                    )
                }
            }

            // Pedoman Murid Quick Entry
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSection(4) }
                    .testTag("pedoman_murid_home_btn")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(
                        imageVector = Icons.Default.Map,
                        contentDescription = "Pedoman Murid",
                        tint = IslamicAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Pedoman Murid",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                    )
                    Text(
                        "Maqamat & Amalan",
                        fontSize = 11.sp,
                        color = SoftGray
                    )
                }
            }
        }
    }
}
