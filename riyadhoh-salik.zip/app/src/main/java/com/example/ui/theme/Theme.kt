package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = EmeraldPrimary,
    secondary = IslamicAmber,
    tertiary = IslamicGold,
    background = EmeraldDarkBackground,
    surface = EmeraldSurfaceCard,
    onPrimary = Color(0xFF021714),
    onSecondary = Color(0xFF221100),
    onTertiary = Color(0xFF221100),
    onBackground = SoftWhite,
    onSurface = SoftWhite
  )

private val LightColorScheme = DarkColorScheme // Force dark emerald theme for consistent Islamic spiritual experience as requested

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme for Emerald Dark Islamic vibe
  dynamicColor: Boolean = false, // Disable dynamic colors to preserve premium custom branding
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
