package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.GeminiSpiritualAdvisor
import com.example.ui.SalikViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

// Structures for Kalam, Adab and Pedoman
data class MursyidQuote(
    val author: String,
    val quote: String,
    val category: String,
    val source: String
)

data class AdabItem(
    val title: String,
    val desc: String,
    val points: List<String>
)

data class PedomanStep(
    val stepNo: Int,
    val name: String,
    val title: String,
    val desc: String,
    val practices: List<String>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MursyidScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // Sub-sections of Mursyid Hub:
    // 0 = Kalam Mursyid, 1 = Tanya Jawab AI, 2 = Adab Murid, 3 = Pedoman Murid, 4 = Muhasabah Jurnal, 5 = Admin Panel
    var activeSubTab by remember { mutableStateOf(0) }
 
    // Intercept back button gestures when browsing sub-sections
    BackHandler(enabled = activeSubTab != 0) {
        activeSubTab = 0
    }
 
    val subTabs = listOf(
        "Kalam Mursyid" to Icons.Default.AutoAwesome,
        "Tanya Jawab AI" to Icons.Default.ChatBubbleOutline,
        "Adab Murid" to Icons.Default.MenuBook,
        "Pedoman" to Icons.Default.Map,
        "Muhasabah" to Icons.Default.LibraryBooks,
        "Admin" to Icons.Default.Settings
    )
 
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldDarkBackground)
    ) {
        // Horizontal Scrollable Scrollbar/Tabrow of Guidance Sections
        ScrollableTabRow(
            selectedTabIndex = activeSubTab,
            containerColor = EmeraldDarkBackground,
            contentColor = EmeraldPrimary,
            edgePadding = 12.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                    color = EmeraldPrimary
                )
            }
        ) {
            subTabs.forEachIndexed { index, (title, icon) ->
                Tab(
                    selected = activeSubTab == index,
                    onClick = { activeSubTab = index },
                    icon = { Icon(icon, contentDescription = title, modifier = Modifier.size(18.dp)) },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (activeSubTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp,
                            color = if (activeSubTab == index) EmeraldPrimary else SoftGray
                        )
                    }
                )
            }
        }
 
        Spacer(modifier = Modifier.height(8.dp))
 
        // Main Animated Stage Transition based on selected section
        AnimatedContent(
            targetState = activeSubTab,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "SubScreenTransition"
        ) { targetIndex ->
            when (targetIndex) {
                0 -> KalamMursyidView(viewModel)
                1 -> TanyaJawabAiView(viewModel)
                2 -> AdabMuridView(viewModel)
                3 -> PedomanMuridView(viewModel)
                4 -> TazkiyahSubScreen(viewModel)
                5 -> AdminPanelScreen(viewModel)
            }
        }
    }
}
 
// ==========================================
// VIEW 1: KALAM MURSYID
// ==========================================
@Composable
fun KalamMursyidView(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // Aphorisms catalog from database room
    val dbKalam by viewModel.kalamList.collectAsState()
    var selectedCategory by remember { mutableStateOf("Semua") }
    var dynamicKalamResult by remember { mutableStateOf<String?>(null) }
    var aiLoadingKalam by remember { mutableStateOf(false) }
 
    val categories = listOf("Semua", "Ikhlas", "Mahabbah", "Sabar", "Zuhud", "Muraqabah")
 
    val filteredKalam = remember(selectedCategory, dbKalam) {
        if (selectedCategory == "Semua") dbKalam
        else dbKalam.filter { it.category == selectedCategory }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("kalam_mursyid_container"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Title
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "HALANGAH KALAM MURSYID",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = IslamicAmber,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            )
            Text(
                text = "Siraman hikmah suci penyejuk gersang sanubari",
                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
            )
        }

        // Live Dynamic Kalam Generator via Gemini AI
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(listOf(IslamicGold.copy(alpha = 0.3f), Color.Transparent)),
                        shape = RoundedCornerShape(24.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Murnikan Niat: Dapatkan Kalam Hikmah Khusus",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = IslamicAmber,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = IslamicGold, modifier = Modifier.size(16.dp))
                    }
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Dapatkan siraman hikmah instan dari Mursyid AI untuk membersihkan noda hati hari ini.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (aiLoadingKalam) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = EmeraldPrimary, modifier = Modifier.size(24.dp))
                        }
                    } else if (dynamicKalamResult != null) {
                        Text(
                            text = dynamicKalamResult ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontStyle = FontStyle.Italic,
                                color = SoftWhite,
                                lineHeight = 20.sp
                            ),
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    aiLoadingKalam = true
                                    dynamicKalamResult = null
                                    try {
                                        dynamicKalamResult = GeminiSpiritualAdvisor.getAdvice("Keluarkan satu baris kalimat kalam hikmah sufi bernuansa thariqah klasik yang membangkitkan keikhlasan.")
                                    } catch (e: Exception) {
                                        dynamicKalamResult = if (dbKalam.isNotEmpty()) dbKalam.random().quote else "Kelemahan yang melahirkan kerendahan hati lebih baik dibanding ketaatan yang melahirkan kesombongan."
                                    } finally {
                                        aiLoadingKalam = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Dapatkan Kalam", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        if (dynamicKalamResult != null) {
                            OutlinedButton(
                                onClick = { dynamicKalamResult = null },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SoftGray),
                                border = ButtonDefaults.outlinedButtonBorder(enabled = true),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Tutup", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Category Ribbon
        item {
            Text(
                "TELUSURI KHASANAH KITAB KLASIK",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = SoftGray,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSel = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) IslamicAmber else EmeraldSurfaceCard)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            cat,
                            color = if (isSel) EmeraldDarkBackground else SoftWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Catalog items list
        items(filteredKalam) { kalam ->
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(EmeraldSecondary.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                kalam.category.uppercase(),
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp
                            )
                        }

                        Text(
                            text = kalam.source,
                            color = SoftGray,
                            fontSize = 11.sp,
                            fontStyle = FontStyle.Italic
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = kalam.quote,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            lineHeight = 22.sp,
                            color = SoftWhite,
                            fontStyle = FontStyle.Normal
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "— ${kalam.author}",
                        color = IslamicGold,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

// ==========================================
// VIEW 2: TANYA JAWAB (AI) DETAILED CHAT
// ==========================================
@Composable
fun TanyaJawabAiView(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var userQuestion by remember { mutableStateOf("") }
    var aiLoading by remember { mutableStateOf(false) }

    // Chat transcript logs
    val messages = remember {
        mutableStateListOf(
            Pair(false, "Assalamu'alaikum wahai penempuh jalan kebajikan. Saya di sini adalah bimbingan Mursyid AI. Tanyakanlah kesulitan hati, kegelisahan ibadah, hasrat duniawi, atau cara khusyuk, niscaya kita raba petunjuk kalam ulama sufi bersama-sama.")
        )
    }

    val quickSuggestions = listOf(
        "Bagaimana cara mengobati riya?",
        "Tips tetap istiqomah saat iman jatuh",
        "Cara agar sholat lebih khusyuk",
        "Mengadukan penyakit malas beribadah"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("ai_chat_view_container")
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "TANYA JAWAB MURSYID AI (RUHANI)",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = IslamicAmber,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Bimbingan interaktif bersumber kitab Al-Ghazali, Al-Hikam dsb.",
                color = SoftGray,
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Message scrolling feed
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(messages) { (isUser, content) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUser) EmeraldPrimary else EmeraldSurfaceCard
                            ),
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 16.dp
                            ),
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isUser) "Anda (Salik)" else "Mursyid AI",
                                    color = if (isUser) EmeraldDarkBackground else IslamicGold,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = content,
                                    color = if (isUser) EmeraldDarkBackground else SoftWhite,
                                    lineHeight = 18.sp,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                if (aiLoading) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(color = IslamicAmber, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Sedang merenungi qolbu...", color = SoftGray, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Quick prompts
            if (messages.size <= 1 && !aiLoading) {
                Text(
                    "PILIH TOPIK KOSONG YANG COCOK:",
                    color = SoftGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickSuggestions) { sug ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(EmeraldSurfaceCard)
                                .clickable { userQuestion = sug }
                                .border(1.dp, EmeraldPrimary.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(sug, color = SoftWhite, fontSize = 11.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Input Tray Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 60.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = userQuestion,
                onValueChange = { userQuestion = it },
                placeholder = { Text("Tulis disini...", color = SoftGray, fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = SoftGray.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("ai_chat_input_text"),
                singleLine = true
            )

            FloatingActionButton(
                onClick = {
                    if (userQuestion.isBlank()) return@FloatingActionButton
                    val q = userQuestion
                    userQuestion = ""
                    messages.add(Pair(true, q))
                    scope.launch {
                        aiLoading = true
                        try {
                            val advice = GeminiSpiritualAdvisor.getAdvice(q)
                            messages.add(Pair(false, advice))
                        } catch (e: Exception) {
                            messages.add(Pair(false, GeminiSpiritualAdvisor.getRandomFallbackQuote()))
                        } finally {
                            aiLoading = false
                        }
                    }
                },
                containerColor = EmeraldPrimary,
                contentColor = EmeraldDarkBackground,
                shape = CircleShape,
                modifier = Modifier
                    .size(52.dp)
                    .testTag("ai_chat_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Kirim", modifier = Modifier.size(18.dp))
            }
        }
    }
}

// ==========================================
// VIEW 3: ADAB MURID EXPANDABLE LIST
// ==========================================
@Composable
fun AdabMuridView(viewModel: SalikViewModel) {
    val items by viewModel.adabList.collectAsState()
    var expandedIndex by remember { mutableStateOf<Int?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("adab_murid_container"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "KITAB ADAB MURID (ETIKET SALIK)",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = IslamicAmber,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Adab mendahului ilmu; rambu-rambu suci penempa perilaku jiwa",
                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        itemsIndexed(items) { index, adab ->
            val isExpanded = expandedIndex == index

            Card(
                onClick = { expandedIndex = if (isExpanded) null else index },
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(EmeraldSecondary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "${index + 1}",
                                    color = EmeraldDarkBackground,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = adab.title,
                                fontWeight = FontWeight.Bold,
                                color = SoftWhite,
                                fontSize = 15.sp
                            )
                        }

                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Detail",
                            tint = EmeraldPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = adab.desc,
                        color = SoftGray,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 16.sp
                    )

                    AnimatedVisibility(visible = isExpanded) {
                        Column(
                            modifier = Modifier
                                .padding(top = 16.dp)
                                .border(1.dp, EmeraldPrimary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.02f))
                                .padding(12.dp)
                        ) {
                            Text(
                                "BUTIR-BUTIR ADAB UTAMA:",
                                color = IslamicGold,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            val points = adab.pointsText.split("\n").filter { it.isNotBlank() }
                            points.forEach { point ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Text("📿 ", color = IslamicAmber, fontSize = 12.sp)
                                    Text(
                                        text = point,
                                        color = SoftWhite,
                                        fontSize = 12.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

// ==========================================
// VIEW 4: PEDOMAN MURID STEPS ROADMAP
// ==========================================
@Composable
fun PedomanMuridView(viewModel: SalikViewModel) {
    val steps by viewModel.pedomanList.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("pedoman_murid_container"),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "ROADMAP PEDOMAN MURID (MAQAMAT)",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = IslamicAmber,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Fase dan peta jalan penempaan jiwa salik menuju Makrifatullah",
                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        itemsIndexed(steps) { index, step ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Stepper Line & Badge column
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                Brush.radialGradient(listOf(IslamicAmber, IslamicGold)),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${step.stepNo}",
                            color = EmeraldDarkBackground,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }

                    if (index < steps.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(160.dp)
                                .background(IslamicAmber.copy(alpha = 0.3f))
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Detail Step card
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = step.name.uppercase(),
                            color = IslamicGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = step.title,
                            fontWeight = FontWeight.ExtraBold,
                            color = SoftWhite,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = step.desc,
                            color = SoftGray,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "AMALAN & LATIHAN KHUSUS:",
                            color = EmeraldPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        val practices = step.practicesText.split("\n").filter { it.isNotBlank() }
                        practices.forEach { practice ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(practice, color = SoftWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

// ==========================================
// VIEW 5: INTEGRATED TAZKIYAH (JOURNAL) SUB-SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TazkiyahSubScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val journalList by viewModel.journalList.collectAsState()

    var selectedMood by remember { mutableStateOf("Tenang") }
    var inputThoughts by remember { mutableStateOf("") }
    var inputHeartState by remember { mutableStateOf("Syukur") }

    val moodEmojis = mapOf(
        "Tenang" to "💚",
        "Syukur" to "😇",
        "Sabar" to "✊",
        "Cemas" to "🥺",
        "Gelisah" to "⚡"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("integrated_tazkiyah_scroll"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "MUHASABAH JURNAL QOLBU",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = IslamicAmber,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Mata-matai niat buruk, evaluasi nafsu, luruskan ikhlas sanubari.",
                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        "Keadaan Qolbu Hari Ini:",
                        style = MaterialTheme.typography.titleSmall.copy(color = SoftWhite, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        moodEmojis.forEach { (moodName, emoji) ->
                            val isSelected = selectedMood == moodName
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { selectedMood = moodName }
                                    .padding(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSelected) EmeraldPrimary else Color.White.copy(alpha = 0.05f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(emoji, fontSize = 20.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    moodName,
                                    fontSize = 11.sp,
                                    color = if (isSelected) EmeraldPrimary else SoftGray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Maqam Selector
                    Text(
                        "Sifat Hati Dominan:",
                        color = SoftGray,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Syukur", "Sabar", "Ikhlas", "Muraqabah", "Fakir").forEach { state ->
                            val isSel = inputHeartState == state
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) IslamicAmber else Color.White.copy(alpha = 0.05f))
                                    .clickable { inputHeartState = state }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    state,
                                    color = if (isSel) EmeraldDarkBackground else SoftWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = inputThoughts,
                        onValueChange = { inputThoughts = it },
                        label = { Text("Tulis refleksi penempaan jiwa...", color = SoftGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SoftWhite,
                            unfocusedTextColor = SoftWhite,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = SoftGray.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("muhasabah_thoughts_input_sub")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (inputThoughts.isBlank()) {
                                Toast.makeText(context, "Mohon tulis beberapa baris refleksi terlebih dulu.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addJournalEntry(selectedMood, inputThoughts, inputHeartState)
                            Toast.makeText(context, "Muhasabah tercatat!", Toast.LENGTH_SHORT).show()
                            inputThoughts = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SIMPAN CATATAN", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text("RIWAYAT TAZKIYATUN NAFS", color = IslamicAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        if (journalList.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Belum ada log catatan jiwa. Mulailah bermuhasabah pagi ini.",
                        modifier = Modifier.padding(16.dp),
                        color = SoftGray,
                        textAlign = TextAlign.Center,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(journalList, key = { it.id }) { journal ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(moodEmojis[journal.mood] ?: "💚", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(journal.date, color = SoftWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(EmeraldSecondary.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(journal.heartState.uppercase(), color = EmeraldPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 9.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(journal.thoughts, color = SoftWhite, fontSize = 13.sp, lineHeight = 18.sp)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            IconButton(
                                onClick = { viewModel.deleteJournalEntry(journal.id) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red.copy(alpha = 0.4f), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

// ==========================================
// DUMMY STATIC DATABASES
// ==========================================
fun getKalamDatabase(): List<MursyidQuote> {
    return listOf(
        MursyidQuote(
            author = "Ibnu Atha'illah Al-Iskandari",
            quote = "Kelemahan dan kemaksiatan yang membuahkan rasa hina dan fakir (butuh kepada Allah) itu jauh lebih baik daripada ketaatan yang membuahkan rasa mulia dan sombong.",
            category = "Ikhlas",
            source = "Al-Hikam"
        ),
        MursyidQuote(
            author = "Syeikh Abdul Qadir Al-Jailani",
            quote = "Janganlah kamu mencintai kedudukan duniawi, karena dunia menetap di tanganmu, bukan di hatimu. Letakkanlah dunia di tanganmu, akhirat di hatimu, dan Allah di dalam rahasiamu (Sirr).",
            category = "Zuhud",
            source = "Fathul Rabbani"
        ),
        MursyidQuote(
            author = "Imam Al-Ghazali",
            quote = "Nafsu itu seperti seorang budak; bila kau sayangi berlebihan ia melunjak, tapi bila kau sapih dan latih dengan disiplin keras, ia akan menuruti kesucian taqwa.",
            category = "Sabar",
            source = "Ihya Ulumuddin"
        ),
        MursyidQuote(
            author = "Syeikh Junaid Al-Baghdadi",
            quote = "Thariqah kami dipagari oleh sunnah murni Rasulullah. Barangsiapa yang tiada menghafal Al-Quran dan tiada mengkaji hadist, tiada boleh mendekat ke halaqah kami.",
            category = "Muraqabah",
            source = "Risalah Sufiyah"
        ),
        MursyidQuote(
            author = "Rabi'ah Al-Adawiyah",
            quote = "Ya Allah, jika aku menyembah-Mu karena takut neraka, bakarlah aku di dalamnya. Jika aku menyembah karena rindu surga, haramkan aku darinya. Namun jika karena Engkau semata, jangan halangi keindahan Wajah-Mu.",
            category = "Mahabbah",
            source = "Kalam Cinta Rabi'ah"
        ),
        MursyidQuote(
            author = "Ibnu Atha'illah Al-Iskandari",
            quote = "Bagaimana mungkin cermin hatimu bersinar terang, sementara bayangan keduniawian masih melengket di mukanya? Bagaimana mungkin kau melakukan suluk menuju Allah, sedangkan kau masih terbelenggu ego syahwat?",
            category = "Zuhud",
            source = "Al-Hikam"
        )
    )
}

fun getAdabItems(): List<AdabItem> {
    return listOf(
        AdabItem(
            title = "Adab Kepada Sang Pencipta (Khaliq)",
            desc = "Etika salik ketika bertatap rukun dengan Allah SWT dalam keseharian maupun kesunyian.",
            points = listOf(
                "Senantiasa menghidupkan rasa Muraqabah (merasa selalu diawasi oleh Allah SWT).",
                "Ikhlas mutlak dalam berbuat ketaatan, tidak mengais perhatian makhluk.",
                "Husnuzhan (berprasangka sangat baik) terhadap segala rukun qadha dan qadar Allah.",
                "Menjunjung kejujuran batin (Sidiq) dalam setiap lisan doa serta kepatuhan syariat."
            )
        ),
        AdabItem(
            title = "Adab Kepada Guru Ruhani (Syeikh/Mursyid)",
            desc = "Toleransi dan penghormatan salik demi mengalirkan berkah bimbingan.",
            points = listOf(
                "Patuh dan berdamai dengan nasehat mursyid selagi tidak melanggar syariat agama.",
                "Tidak menyelidiki atau mencari sandungan manusiawi pada diri Syeikh.",
                "Memelihara kesopanan lahir-batin serta berkhidmah dengan ikhlas.",
                "Mendoakan keselamatan batiniah dan jasmani Syeikh di tiap sepertiga malam."
            )
        ),
        AdabItem(
            title = "Adab Kepada Sesama Salik (Saudara Seperjalanan)",
            desc = "Saling menopang dan mengasihi demi merajut ukhuwah ruhani.",
            points = listOf(
                "Mendahulukan kepentingan saudara (Itsar) di atas kepentingan ego pribadi.",
                "Menutupi aib serta cacat cela saudara seperjalanan rapat-rapat.",
                "Saling mengingatkan dan menasihati dengan santun diselimuti kelembutan cinta.",
                "Bebas dari kedengkian, hasad, rebutan kemuliaan, atau ghibah."
            )
        ),
        AdabItem(
            title = "Adab Kepada Diri Sendiri (Muamalah Batin)",
            desc = "Disiplin salik dalam menata hawa nafsu dan kesucian akal.",
            points = listOf(
                "Menjaga kesucian wudhu di setiap waktu secara kontinyu (Daimul Wudhu).",
                "Senantiasa melatih lapar yang terkontrol (Siyam) dan membatasi bicara yang sia-sia.",
                "Mata-matai niat di setiap perbuatan, menyingkirkan bibit Ujub dan Riya.",
                "Mewajibkan hisab diri (Muhasabah) sebelum beristirahat tidur malam."
            )
        )
    )
}

fun getPedomanSteps(): List<PedomanStep> {
    return listOf(
        PedomanStep(
            stepNo = 1,
            name = "YAQZHAH & TAUBAT",
            title = "Keterbangunan Jiwa (Yaqzhah)",
            desc = "Fase awal di mana seorang hamba terbangun dari tidur kelalaian (ghafilah), menyadari dosa-dosa masa lalu, dan melakukan penyesalan murni (Taubat Nasuha).",
            practices = listOf(
                "Istighfar minimal 100x setiap fajar",
                "Meninggalkan majelis maksiat & laghwi",
                "Menyelesaikan hak-hak bersalah antar manusia"
            )
        ),
        PedomanStep(
            stepNo = 2,
            name = "TAKHAL-LI (PEMBERSIHAN)",
            title = "Pengosongan Hati (Takhalli)",
            desc = "Suluk mengikis dan mengosongkan hati dari sifat-sifat tercela (Madzmumah) seperti dengki, takabur, riya, cinta dunia, serta keinginan dipuji makhluk.",
            practices = listOf(
                "Muhasabah qolbu terjadwal",
                "Latihan diam dari berdebat kosong",
                "Riyadhah tidak pamer amalan saleh"
            )
        ),
        PedomanStep(
            stepNo = 3,
            name = "TAHAL-LI (PENGHISAN)",
            title = "Penghiasan Batin (Tahalli)",
            desc = "Fase mendekorasi ruang hati yang sudah bersih dengan sifat-sifat mulia (Mahmudah) seperti ikhlas, rida, syukur, tawakal, mahabbah, dan sabar.",
            practices = listOf(
                "Dzikir dawam Pagi & Petang tanpa putus",
                "Membiasakan sedekah sirr (sembunyi)",
                "Senantiasa rida atas cobaan takdir"
            )
        ),
        PedomanStep(
            stepNo = 4,
            name = "TAJAL-LI & WUSUL",
            title = "Pancaran Cahaya Divine (Tajalli)",
            desc = "Masuk ke maqam kedekatan yang suci, di mana hijab batin tersingkap dan salik merasakan lezatnya kedamaian batin bersanding Ridha Ilahi.",
            practices = listOf(
                "Sholat tahajjud & munajat khusyuk",
                "Dzikir Sirr (dalam kalbu terdalam)",
                "Senantiasa Muraqabah di setiap hembusan"
            )
        )
    )
}

// ==========================================
// VIEW 6: KHASANAH ADMIN PANEL SCREEN & VIEWS
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    var isAuthenticated by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    if (!isAuthenticated) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
                    .border(1.dp, IslamicAmber.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(IslamicAmber.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Terkunci",
                            tint = IslamicAmber,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Text(
                        text = "GERBANG KHIDMAT ADMIN",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = SoftWhite,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )

                    Text(
                        text = "Masukkan kata sandi khidmat untuk mengelola konten dan khasanah secara dinamis.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SoftGray),
                        textAlign = TextAlign.Center
                    )

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Kata Sandi", color = SoftGray) },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            val image = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(imageVector = image, contentDescription = "Toggle password visibility", tint = SoftGray)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SoftWhite,
                            unfocusedTextColor = SoftWhite,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = SoftGray.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("admin_password_input")
                    )

                    Button(
                        onClick = {
                            val normalized = passwordInput.trim().lowercase()
                            if (normalized == "bismillah" || normalized == "admin123" || normalized == "admin") {
                                isAuthenticated = true
                                Toast.makeText(context, "Akses Admin Terbuka!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Sandi salah! Cobalah 'bismillah'", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_unlock_button")
                    ) {
                        Text(
                            text = "BUKA AKSES",
                            color = EmeraldDarkBackground,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    Text(
                        text = "Sandi default: bismillah",
                        style = MaterialTheme.typography.bodySmall.copy(color = IslamicGold.copy(alpha = 0.7f)),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        return
    }

    var manageCategory by remember { mutableStateOf(0) } // 0 = Kalam, 1 = Adab, 2 = Pedoman, 3 = Quran

    val adminCategories = listOf("Kalam Mursyid", "Adab Murid", "Pedoman", "Al-Quran")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "ADMIN PANEL PENGELOLA KONTEN",
            style = MaterialTheme.typography.titleMedium.copy(
                color = IslamicAmber,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Text(
            text = "Kelola khasanah suluk, adab (etiket), pedoman tahapan maqamat, beserta mushaf Al-Quran thariqah secara dinamis.",
            style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
        )

        // Custom Category Ribbon Selector
        SingleSelectionCategoryRow(
            categories = adminCategories,
            selectedIndex = manageCategory,
            onSelect = { manageCategory = it }
        )

        Spacer(modifier = Modifier.height(4.dp))

        when (manageCategory) {
            0 -> ManageKalamView(viewModel)
            1 -> ManageAdabView(viewModel)
            2 -> ManagePedomanView(viewModel)
            3 -> ManageQuranView(viewModel)
        }
        
        Spacer(modifier = Modifier.height(100.dp))
    }
}

@Composable
fun SingleSelectionCategoryRow(
    categories: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        itemsIndexed(categories) { index, cat ->
            val isSelected = selectedIndex == index
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) IslamicAmber else EmeraldSurfaceCard)
                    .clickable { onSelect(index) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    cat,
                    color = if (isSelected) EmeraldDarkBackground else SoftWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageKalamView(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val list by viewModel.kalamList.collectAsState()

    var author by remember { mutableStateOf("") }
    var quote by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Ikhlas") }
    var source by remember { mutableStateOf("") }

    val categories = listOf("Ikhlas", "Mahabbah", "Sabar", "Zuhud", "Muraqabah")

    Card(
        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Tambah Kalam Hikmah Baru", color = IslamicGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)

            OutlinedTextField(
                value = author,
                onValueChange = { author = it },
                label = { Text("Nama Tokoh / Pengarang / Mursyid", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = quote,
                onValueChange = { quote = it },
                label = { Text("Kalam / Quote Hikmah Sufi", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Category select row
            Text("Kategori Kalam:", color = SoftGray, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                categories.forEach { cat ->
                    val isSel = category == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) EmeraldPrimary else Color.White.copy(alpha = 0.05f))
                            .clickable { category = cat }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(cat, color = if (isSel) EmeraldDarkBackground else SoftWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            OutlinedTextField(
                value = source,
                onValueChange = { source = it },
                label = { Text("Kitab Rujukan (e.g. Al-Hikam)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (author.isBlank() || quote.isBlank() || source.isBlank()) {
                        Toast.makeText(context, "Mohon lengkapi semua isian", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    viewModel.addKalam(author, quote, category, source)
                    Toast.makeText(context, "Kalam Hikmah ditambahkan!", Toast.LENGTH_SHORT).show()
                    author = ""
                    quote = ""
                    source = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("SIMPAN KALAM", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))
    Text("Daftar Kalam Hikmah Saat Ini:", color = IslamicAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)

    list.forEach { item ->
        Card(
            colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.quote, color = SoftWhite, fontSize = 13.sp, fontStyle = FontStyle.Italic)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("— ${item.author} (${item.source})", color = IslamicGold, fontSize = 11.sp)
                }
                IconButton(onClick = { viewModel.deleteKalam(item.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageAdabView(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val list by viewModel.adabList.collectAsState()

    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var pointsText by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Tambah Bab Adab Salik", color = IslamicGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Judul Bab Adab", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text("Deskripsi Singkat", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = pointsText,
                onValueChange = { pointsText = it },
                label = { Text("Butir-butir Adab (Satu butir per baris)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                placeholder = { Text("Contoh:\nButir pertama adab\nButir kedua adab") },
                modifier = Modifier.fillMaxWidth().height(100.dp)
            )

            Button(
                onClick = {
                    if (title.isBlank() || desc.isBlank() || pointsText.isBlank()) {
                        Toast.makeText(context, "Mohon lengkapi semua isian", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    viewModel.addAdab(title, desc, pointsText.trim())
                    Toast.makeText(context, "Adab baru ditambahkan!", Toast.LENGTH_SHORT).show()
                    title = ""
                    desc = ""
                    pointsText = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("SIMPAN ADAB", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))
    Text("Daftar Bab Adab Saat Ini:", color = IslamicAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)

    list.forEach { item ->
        Card(
            colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.title, color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(item.desc, color = SoftGray, fontSize = 11.sp)
                }
                IconButton(onClick = { viewModel.deleteAdab(item.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagePedomanView(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val list by viewModel.pedomanList.collectAsState()

    var stepNoText by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var practicesText by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Tambah Peta Langkah Pedoman", color = IslamicGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)

            OutlinedTextField(
                value = stepNoText,
                onValueChange = { stepNoText = it },
                label = { Text("Nomor Urut Langkah (e.g. 1)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Label Langkah (e.g. YAQZHAH)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Judul Langkah Maqam", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text("Deskripsi Peringkat", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = practicesText,
                onValueChange = { practicesText = it },
                label = { Text("Latihan & Amalan (Satu amalan per baris)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth().height(100.dp)
            )

            Button(
                onClick = {
                    val stepNo = stepNoText.toIntOrNull()
                    if (stepNo == null || name.isBlank() || title.isBlank() || desc.isBlank() || practicesText.isBlank()) {
                        Toast.makeText(context, "Mohon lengkapi semua isian dengan valid", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    viewModel.addPedoman(stepNo, name, title, desc, practicesText.trim())
                    Toast.makeText(context, "Langkah Pedoman ditambahkan!", Toast.LENGTH_SHORT).show()
                    stepNoText = ""
                    name = ""
                    title = ""
                    desc = ""
                    practicesText = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("SIMPAN PEDOMAN", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))
    Text("Daftar Langkah Pedoman Saat Ini:", color = IslamicAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)

    list.forEach { item ->
        Card(
            colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Langkah ${item.stepNo}: ${item.name}", color = IslamicGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(item.title, color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { viewModel.deletePedoman(item.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageQuranView(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val list by viewModel.quranList.collectAsState()

    var numberText by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var arabicName by remember { mutableStateOf("") }
    var revelation by remember { mutableStateOf("Makkiyah") }
    var versesText by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Tambah Mushaf Surah Baru", color = IslamicGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)

            OutlinedTextField(
                value = numberText,
                onValueChange = { numberText = it },
                label = { Text("Nomor Surah (e.g. 1)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama Surah & Terjemahan (e.g. Al-Fatihah (Pembuka))", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = arabicName,
                onValueChange = { arabicName = it },
                label = { Text("Nama Surah Arab (e.g. الفاتحة)", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Revelation
            Text("Tempat Turun Surah:", color = SoftGray, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("Makkiyah", "Madaniyyah").forEach { rev ->
                    val isSel = revelation == rev
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) EmeraldPrimary else Color.White.copy(alpha = 0.05f))
                            .clickable { revelation = rev }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(rev, color = if (isSel) EmeraldDarkBackground else SoftWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            OutlinedTextField(
                value = versesText,
                onValueChange = { versesText = it },
                label = { Text("Teks Ayat (Format: nomor||arab||arti [satu per baris])", color = SoftGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SoftWhite,
                    unfocusedTextColor = SoftWhite,
                    focusedBorderColor = EmeraldPrimary
                ),
                placeholder = { Text("Contoh:\n1||الْحَمْدُ لِلَّهِ||Segala puji bagi Allah\n2||الرَّحْمَنِ||Yang Maha Pengasih") },
                modifier = Modifier.fillMaxWidth().height(120.dp)
            )

            Button(
                onClick = {
                    val number = numberText.toIntOrNull()
                    val rawVerses = versesText.split("\n").filter { it.isNotBlank() }
                    if (number == null || name.isBlank() || arabicName.isBlank() || rawVerses.isEmpty()) {
                        Toast.makeText(context, "Mohon lengkapi semua isian secara valid", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    viewModel.addQuran(number, name, arabicName, revelation, rawVerses.size, versesText.trim())
                    Toast.makeText(context, "Surah ditambahkan ke database!", Toast.LENGTH_SHORT).show()
                    numberText = ""
                    name = ""
                    arabicName = ""
                    versesText = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("SIMPAN SURAH MUSHAF", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))
    Text("Daftar Surah Mushaf Saat Ini:", color = IslamicAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)

    list.forEach { item ->
        Card(
            colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("${item.number}. ${item.name}", color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("${item.revelation} • ${item.versesCount} Ayat", color = SoftGray, fontSize = 11.sp)
                }
                IconButton(onClick = { viewModel.deleteQuran(item.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red.copy(alpha = 0.6f))
                }
            }
        }
    }
}
