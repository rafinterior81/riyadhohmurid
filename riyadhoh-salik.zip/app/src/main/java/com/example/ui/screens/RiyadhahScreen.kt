package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RiyadhahEntity
import com.example.ui.SalikViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiyadhahScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val selectedDateString by viewModel.selectedDateString.collectAsState()
    val riyadhohList by viewModel.riyadhohList.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    // Aggregate progress
    val completedCount = riyadhohList.count { it.isCompleted }
    val totalCount = riyadhohList.size
    val progressPct = if (totalCount > 0) (completedCount.toFloat() / totalCount) else 0f

    // Calculate dynamic 7-day ribbon around today
    val calendarDays = remember {
        val list = mutableListOf<Date>()
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -3) // 3 days ago
        for (i in 0..6) {
            list.add(cal.time)
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        list
    }

    val dayFormat = SimpleDateFormat("E", Locale.getDefault())
    val dayNumFormat = SimpleDateFormat("d", Locale.getDefault())
    val dateStringFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = EmeraldDarkBackground,
                modifier = Modifier.testTag("add_riyadhah_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Target")
            }
        },
        containerColor = EmeraldDarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "WALK OF RIYADHAH",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = IslamicAmber,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Latihan disiplin amalan untuk melatih keteguhan jiwa",
                    style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Interactive 7-Day Ribbon Layout
                LazyRow(
                    modifier = Modifier.fillMaxWidth().testTag("date_ribbon"),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(calendarDays) { date ->
                        val dateStr = dateStringFormat.format(date)
                        val isSelected = dateStr == selectedDateString
                        val isToday = dateStr == dateStringFormat.format(Date())

                        Card(
                            onClick = { viewModel.selectDate(dateStr) },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) EmeraldPrimary else EmeraldSurfaceCard
                            ),
                            modifier = Modifier
                                .width(56.dp)
                                .height(72.dp)
                                .border(
                                    width = 1.dp,
                                    color = if (isToday && !isSelected) IslamicAmber else Color.Transparent,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .testTag("date_card_$dateStr")
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = dayFormat.format(date).uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSelected) EmeraldDarkBackground else SoftGray,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = dayNumFormat.format(date),
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = if (isSelected) EmeraldDarkBackground else SoftWhite,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Progress Banner Card
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("riyadhah_progress_card"),
                    colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "ISTIQOMAH SCORE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = IslamicAmber,
                                    letterSpacing = 1.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                if (totalCount > 0) "${(progressPct * 100).toInt()}% Amalan Selesai" else "Belum memulai",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SoftWhite
                                )
                            )
                            Text(
                                "Tuntas $completedCount dari $totalCount amalan penempa jiwa",
                                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                            )
                        }

                        // Circular Progress Indicator
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                progress = { progressPct },
                                modifier = Modifier.size(64.dp),
                                color = EmeraldPrimary,
                                trackColor = EmeraldDarkBackground,
                                strokeWidth = 6.dp
                            )
                            Text(
                                text = "$completedCount/$totalCount",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SoftWhite
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Checklist rows
                if (riyadhohList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Memuat Target Riyadhah...", color = SoftGray)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        items(riyadhohList, key = { it.id }) { item ->
                            Card(
                                onClick = { viewModel.toggleRiyadhah(item.id, item.isCompleted) },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (item.isCompleted) EmeraldSurfaceCard.copy(alpha = 0.6f) else EmeraldSurfaceCard
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("riyadhah_item_${item.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (item.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = "Status",
                                        tint = if (item.isCompleted) EmeraldPrimary else SoftGray,
                                        modifier = Modifier.size(24.dp)
                                    )

                                    Spacer(modifier = Modifier.width(16.dp))

                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (item.isCompleted) FontWeight.Normal else FontWeight.SemiBold,
                                            color = if (item.isCompleted) SoftGray else SoftWhite,
                                            textDecoration = if (item.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                                        )
                                    )
                                }
                            }
                        }
                        item {
                            Spacer(modifier = Modifier.height(80.dp))
                        }
                    }
                }
            }
        }

        // Add Riyadhah Dialog
        if (showAddDialog) {
            var newTitle by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Tambah Target Riyadhah", color = SoftWhite, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("Tulis nama amalan riyadhah...") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = SoftWhite,
                                unfocusedTextColor = SoftWhite,
                                focusedBorderColor = EmeraldPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("add_riyadhah_title")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newTitle.isNotBlank()) {
                                viewModel.addNewRiyadhah(newTitle)
                                Toast.makeText(context, "Target ditambahkan!", Toast.LENGTH_SHORT).show()
                                showAddDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("Simpan", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Batal", color = SoftGray)
                    }
                },
                containerColor = EmeraldSurfaceCard
            )
        }
    }
}
