package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF0DD39F)
val EmeraldSecondary = Color(0xFF00AA7C)
val EmeraldDarkBackground = Color(0xFF041E1A)
val EmeraldSurfaceCard = Color(0xFF072A24)
val EmeraldSurfaceCardGradientStart = Color(0xFF0A4037)
val EmeraldSurfaceCardGradientEnd = Color(0xFF072922)

val IslamicAmber = Color(0xFFFFA000)
val IslamicGold = Color(0xFFFFD54F)
val SoftWhite = Color(0xFFF0FAF7)
val SoftGray = Color(0xFFB5C9C5)
val NextAsharGreen = Color(0xFF64FFDA)

