package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.BookmarkAdded
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SalikViewModel
import com.example.ui.theme.*

data class SurahModel(
    val number: Int,
    val name: String,
    val arabicName: String,
    val revelation: String,
    val versesCount: Int,
    val verses: List<VerseModel>
)

data class VerseModel(
    val number: Int,
    val arabicText: String,
    val translation: String
)

fun com.example.data.QuranSurahEntity.toSurahModel(): SurahModel {
    val verseLines = this.versesText.split("\n").filter { it.isNotBlank() }
    val verses = verseLines.map { line ->
        val parts = line.split("||")
        val num = parts.getOrNull(0)?.toIntOrNull() ?: 1
        val arab = parts.getOrNull(1) ?: ""
        val translation = parts.getOrNull(2) ?: ""
        VerseModel(num, arab, translation)
    }
    return SurahModel(
        number = this.number,
        name = this.name,
        arabicName = this.arabicName,
        revelation = this.revelation,
        versesCount = this.versesCount,
        verses = verses
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedSurah by remember { mutableStateOf<SurahModel?>(null) }
    var mAudioPlaying by remember { mutableStateOf(false) }

    // Intercept back presses to exit the reading view gracefully
    BackHandler(enabled = selectedSurah != null) {
        selectedSurah = null
        mAudioPlaying = false
    }

    val quranList by viewModel.quranList.collectAsState()
    val dbSurahs = remember(quranList) {
        quranList.map { it.toSurahModel() }
    }

    val filteredSurahs = remember(searchQuery, dbSurahs) {
        if (searchQuery.isBlank()) {
            dbSurahs
        } else {
            dbSurahs.filter { it.name.contains(searchQuery, ignoreCase = true) || it.revelation.contains(searchQuery, ignoreCase = true) }
        }
    }

    Scaffold(
        containerColor = EmeraldDarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (selectedSurah == null) {
                // Main Surahs Listing Mode
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MUSHAF TILAWAH QURAN",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = IslamicAmber,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Penyejuk qolbu para musafir ruhani",
                        style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search box
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quran_search_input"),
                        placeholder = { Text("Cari Surah...", color = SoftGray) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari", tint = EmeraldPrimary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SoftWhite,
                            unfocusedTextColor = SoftWhite,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = SoftGray.copy(alpha = 0.3f)
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Surah list
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize().testTag("surah_list")
                    ) {
                        items(filteredSurahs) { surah ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedSurah = surah },
                                colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Number badge
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .background(EmeraldSecondary, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "${surah.number}",
                                                color = EmeraldDarkBackground,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(16.dp))

                                        Column {
                                            Text(
                                                text = surah.name,
                                                style = MaterialTheme.typography.titleMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = SoftWhite
                                                )
                                            )
                                            Text(
                                                text = "${surah.revelation} • ${surah.versesCount} Ayat",
                                                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                                            )
                                        }
                                    }

                                    // Arabic calligraphy styled name
                                    Text(
                                        text = surah.arabicName,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IslamicGold,
                                        textAlign = TextAlign.End
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Reading mode inside selected Surah
                val surah = selectedSurah!!

                Column(modifier = Modifier.fillMaxSize()) {
                    // Header bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(EmeraldSurfaceCard)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                selectedSurah = null
                                mAudioPlaying = false
                            }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Kembali", tint = SoftWhite)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = surah.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = SoftWhite
                                    )
                                )
                                Text(
                                    text = "${surah.revelation} • ${surah.versesCount} Ayat",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SoftGray)
                                )
                            }
                        }

                        // Bookmark and Audio
                        Row {
                            IconButton(onClick = {
                                viewModel.updateLastRead(surah.name, 1)
                                Toast.makeText(context, "📌 Ditandai Terakhir Baca: ${surah.name}", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Outlined.Book, contentDescription = "Tandai Baca", tint = IslamicGold)
                            }

                            IconButton(onClick = {
                                mAudioPlaying = !mAudioPlaying
                                if (mAudioPlaying) {
                                    Toast.makeText(context, "🔊 Murottal Surah ${surah.name} disimulasikan putar suara merdu syeikh...", Toast.LENGTH_LONG).show()
                                }
                            }) {
                                Icon(
                                    imageVector = if (mAudioPlaying) Icons.Default.PauseCircleFilled else Icons.Outlined.PlayCircle,
                                    contentDescription = "Simulasi Audio",
                                    tint = EmeraldPrimary
                                )
                            }
                        }
                    }

                    // Basmalah except Al-Fatihah/At-Tawbah (or simple nice spacer)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(EmeraldSurfaceCard.copy(alpha = 0.5f))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IslamicGold,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Audio playing simulator ribbon
                    AnimatedVisibility(visible = mAudioPlaying) {
                        Surface(color = EmeraldSecondary.copy(alpha = 0.2f)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        color = EmeraldPrimary,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "Memutar Audio Murottal Syeikh Al-Ghamidi...",
                                        style = MaterialTheme.typography.labelSmall.copy(color = SoftWhite)
                                    )
                                }
                                Text(
                                    "0:42 / 3:15",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SoftGray)
                                )
                            }
                        }
                    }

                    // Verse Reader List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .testTag("verses_container"),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        itemsIndexed(surah.verses) { index, verse ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = if (index % 2 == 0) EmeraldSurfaceCard.copy(alpha = 0.3f) else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                // Verse numbering banner
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .background(EmeraldSurfaceCard, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${verse.number}",
                                            color = IslamicGold,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    // Tap to tag bookmark specifically or listen
                                    IconButton(
                                        onClick = {
                                            viewModel.updateLastRead(surah.name, verse.number)
                                            Toast.makeText(context, "📌 Ditandai Terakhir Baca: ${surah.name} Ayat ${verse.number}", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.BookmarkBorder,
                                            contentDescription = "Bookmark Verse",
                                            tint = SoftGray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Arabic representation
                                Text(
                                    text = verse.arabicText,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SoftWhite,
                                    lineHeight = 44.sp,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Translation text representation
                                Text(
                                    text = verse.translation,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Light,
                                    color = SoftGray,
                                    lineHeight = 20.sp,
                                    textAlign = TextAlign.Left
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Full Dummy data of 6 powerful Quran Surahs for Saliks
fun getDummySurahData(): List<SurahModel> {
    return listOf(
        SurahModel(
            number = 1,
            name = "Al-Fatihah (Pembuka)",
            arabicName = "الفاتحة",
            revelation = "Makkiyah",
            versesCount = 7,
            verses = listOf(
                VerseModel(1, "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", "Segala puji bagi Allah, Tuhan seluruh alam."),
                VerseModel(2, "الرَّحْمَنِ الرَّحِيمِ", "Yang Maha Pengasih, Maha Penyayang."),
                VerseModel(3, "مَالِكِ يَوْمِ الدِّينِ", "Pemilik hari pembalasan."),
                VerseModel(4, "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami memohon pertolongan."),
                VerseModel(5, "اهدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", "Tunjukkanlah kami jalan yang lurus."),
                VerseModel(6, "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ", "(yaitu) jalan orang-orang yang telah Engkau beri nikmat kepadanya;"),
                VerseModel(7, "غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلاَ الضَّالِّينَ", "bukan (jalan) mereka yang dimurkai, dan bukan (pula jalan) mereka yang sesat.")
            )
        ),
        SurahModel(
            number = 36,
            name = "Yasin",
            arabicName = "يس",
            revelation = "Makkiyah",
            versesCount = 5,
            verses = listOf(
                VerseModel(1, "يسَّ", "Ya Sin."),
                VerseModel(2, "وَالْقُرْآنِ الْحَكِيمِ", "Demi Al-Qur'an yang penuh hikmah,"),
                VerseModel(3, "إِنَّكَ لَمِنَ الْمُرْسَلِينَ", "sungguh, engkau (Muhammad) adalah salah seorang dari rasul-rasul,"),
                VerseModel(4, "عَلَىٰ صِرَاطٍ مُسْتَقِيمٍ", "(yang berada) di atas jalan yang lurus,"),
                VerseModel(5, "تَنْزِيلَ الْعَزِيزِ الرَّحِيمِ", "(sebagai wahyu) yang diturunkan oleh (Allah) Yang Mahaperkasa, Maha Penyayang,")
            )
        ),
        SurahModel(
            number = 55,
            name = "Ar-Rahman",
            arabicName = "الرحمن",
            revelation = "Madaniyyah",
            versesCount = 5,
            verses = listOf(
                VerseModel(1, "الرَّحْمَٰنُ", "(Allah) Yang Maha Pengasih,"),
                VerseModel(2, "عَلَّمَ الْقُرْآنَ", "Yang telah mengajarkan Al-Qur'an."),
                VerseModel(3, "خَلَقَ الْإِنْسَانَ", "Dia menciptakan manusia,"),
                VerseModel(4, "عَلَّمَهُ الْبَيَانَ", "Mengajarnya pandai berbicara."),
                VerseModel(5, "الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ", "Matahari dan bulan beredar menurut perhitungan.")
            )
        ),
        SurahModel(
            number = 56,
            name = "Al-Waqi'ah",
            arabicName = "الواقعة",
            revelation = "Makkiyah",
            versesCount = 4,
            verses = listOf(
                VerseModel(1, "إِذَا وَقَعَتِ الْوَاقِعَةُ", "Apabila terjadi hari kiamat,"),
                VerseModel(2, "لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ", "terjadinya tidak dapat didustakan (disangkal)."),
                VerseModel(3, "خَافِضَةٌ رَافِعَةٌ", "(Kejadian itu) merendahkan (satu golongan) dan meninggikan (golongan yang lain),"),
                VerseModel(4, "إِذَا رُجَّتِ الْأَرْضُ رَجًّا", "apabila bumi digoncangkan sedahsyat-dahsyatnya,")
            )
        ),
        SurahModel(
            number = 67,
            name = "Al-Mulk",
            arabicName = "الملك",
            revelation = "Makkiyah",
            versesCount = 5,
            verses = listOf(
                VerseModel(1, "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", "Mahasuci Allah yang menguasai (segala) kerajaan, dan Dia Mahakuasa atas segala sesuatu,"),
                VerseModel(2, "الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ", "Yang menciptakan mati dan hidup, untuk menguji kamu, siapa di antara kamu yang lebih baik amalnya. Dan Dia Mahaperkasa, Maha Pengampun,"),
                VerseModel(3, "الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلَقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ", "Yang menciptakan tujuh langit berlapis-lapis. Tidak akan kamu lihat sesuatu yang tidak seimbang pada ciptaan (Allah) Yang Maha Pengasih. Maka lihatlah sekali lagi, adakah kamu lihat sesuatu yang cacat?"),
                VerseModel(4, "ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ", "Kemudian ulangi pandanganmu dua kali lagi, niscaya pandanganmu akan kembali kepadamu tanpa menemukan cacat dan ia dalam keadaan letih."),
                VerseModel(5, "وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ", "Dan sungguh, Telah Kami hiasi langit yang dekat dengan pelita-pelita, dan Kami jadikan pelita-pelita itu penyembur syaitan...")
            )
        ),
        SurahModel(
            number = 112,
            name = "Al-Ikhlas (Keesaan)",
            arabicName = "الإخلاص",
            revelation = "Makkiyah",
            versesCount = 4,
            verses = listOf(
                VerseModel(1, "قُلْ هُوَ اللَّهُ أَحَدٌ", "Katakanlah (Muhammad), \"Dialah Allah, Yang Maha Esa."),
                VerseModel(2, "اللَّهُ الصَّمَدُ", "Allah tempat meminta segala sesuatu."),
                VerseModel(3, "لَمْ يَلِدْ وَلَمْ يُولَدْ", "Dia tidak beranak dan tidak pula diperanakkan,"),
                VerseModel(4, "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "dan tidak ada sesuatu yang setara dengan Dia.\"")
            )
        )
    )
}
