package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.JournalEntity
import com.example.ui.GeminiSpiritualAdvisor
import com.example.ui.SalikViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TazkiyahScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val journalList by viewModel.journalList.collectAsState()

    // Tab state (0 = Muhasabah Jurnal, 1 = Tanya Mursyid AI)
    var selectedTab by remember { mutableStateOf(0) }

    // Muhasabah states
    var selectedMood by remember { mutableStateOf("Tenang") }
    var inputThoughts by remember { mutableStateOf("") }
    var inputHeartState by remember { mutableStateOf("Syukur") }

    // Tanya Mursyid AI states
    var userQuestion by remember { mutableStateOf("") }
    var rawAdviceResult by remember { mutableStateOf<String?>(null) }
    var aiLoading by remember { mutableStateOf(false) }

    val moodEmojis = mapOf(
        "Tenang" to "💚",
        "Syukur" to "😇",
        "Sabar" to "✊",
        "Cemas" to "🥺",
        "Gelisah" to "⚡"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldDarkBackground)
    ) {
        // Core Tab selector for Tazkiyah
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = EmeraldDarkBackground,
            contentColor = EmeraldPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = EmeraldPrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Muhasabah Harian", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Tanya Mursyid AI", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            // Muhasabah Jurnal View and history
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("tazkiyah_scroll"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Topic card
                item {
                    Text(
                        text = "TAZKIYATUN NAFS (Pembersihan Jiwa)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = IslamicAmber,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Evaluasi kebersihan qolbu, luruskan niat amalan.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                    )
                }

                // Muhasabah Input Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                brush = Brush.verticalGradient(listOf(IslamicGold.copy(alpha = 0.2f), Color.Transparent)),
                                shape = RoundedCornerShape(24.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                "Bagaimana Kondisi Qolbu Anda Hari Ini?",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SoftWhite
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Interactive mood row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                moodEmojis.forEach { (moodName, emoji) ->
                                    val isSelected = selectedMood == moodName
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .clickable { selectedMood = moodName }
                                            .padding(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    if (isSelected) EmeraldPrimary else Color.White.copy(alpha = 0.05f)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(emoji, fontSize = 24.sp)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            moodName,
                                            fontSize = 11.sp,
                                            color = if (isSelected) EmeraldPrimary else SoftGray,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Active primary heart state selector
                            Text(
                                "Atribut Maqam Hati Utama:",
                                style = MaterialTheme.typography.bodySmall.copy(color = SoftGray, fontWeight = FontWeight.SemiBold)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Ikhlas", "Syukur", "Sabar", "Muraqabah", "Fakir").forEach { state ->
                                    val isSel = inputHeartState == state
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSel) IslamicAmber else Color.White.copy(alpha = 0.05f))
                                            .clickable { inputHeartState = state }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            state,
                                            color = if (isSel) EmeraldDarkBackground else SoftWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Input text area
                            OutlinedTextField(
                                value = inputThoughts,
                                onValueChange = { inputThoughts = it },
                                label = { Text("Tulis refleksi / catatan muhasabah jiwa...", color = SoftGray) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = SoftWhite,
                                    unfocusedTextColor = SoftWhite,
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = SoftGray.copy(alpha = 0.2f)
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .testTag("muhasabah_thoughts_input")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (inputThoughts.isBlank()) {
                                        Toast.makeText(context, "Mohon tulis beberapa catatan muhasabah dulu.", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    viewModel.addJournalEntry(selectedMood, inputThoughts, inputHeartState)
                                    Toast.makeText(context, "Muhasabah berhasil tercatat!", Toast.LENGTH_SHORT).show()
                                    inputThoughts = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                modifier = Modifier.fillMaxWidth().testTag("save_muhasabah_button")
                            ) {
                                Text("SIMPAN MUHASABAH", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // History Title
                item {
                    Text(
                        "RIWAYAT MUHASABAH JURNAL",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = IslamicAmber,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }

                // History items
                if (journalList.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "Belum ada catatan muhasabah sebelumnya. Mulailah menulis refleksi hari ini.",
                                modifier = Modifier.padding(18.dp),
                                color = SoftGray,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    items(journalList, key = { it.id }) { journal ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth().testTag("journal_item_${journal.id}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(moodEmojis[journal.mood] ?: "💚", fontSize = 18.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = journal.date,
                                            color = SoftWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }

                                    // Attribute Badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(EmeraldSecondary.copy(alpha = 0.2f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            journal.heartState.uppercase(),
                                            color = EmeraldPrimary,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = journal.thoughts,
                                    color = SoftWhite,
                                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteJournalEntry(journal.id)
                                            Toast.makeText(context, "Log muhasabah dihapus", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Hapus",
                                            tint = Color.Red.copy(alpha = 0.5f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Tanya Mursyid AI View
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Topic card
                Column {
                    Text(
                        text = "TANYA MURSYID AI (KONSULTASI RUHANI)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = IslamicAmber,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Ajukan kesusahan jiwa atau kerikil ibadah, dapatkan bimbingan nasehat bersumber kalam hikmah Sufi.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                    )
                }

                // Ask area input
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(
                            "Keluhan / Pertanyaan Khusus Jiwa Anda:",
                            style = MaterialTheme.typography.titleSmall.copy(color = SoftWhite, fontWeight = FontWeight.Bold)
                        )

                        OutlinedTextField(
                            value = userQuestion,
                            onValueChange = { userQuestion = it },
                            placeholder = { Text("Contoh: Saya sering merasa sombong setelah sedekah, dan sulit khusyuk sholat...", color = SoftGray) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = SoftWhite,
                                unfocusedTextColor = SoftWhite,
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = SoftGray.copy(alpha = 0.3f)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("mursyid_question_input")
                        )

                        Button(
                            onClick = {
                                if (userQuestion.isBlank()) {
                                    Toast.makeText(context, "Silahkan ajukan unek-unek hati Anda terlebih dahulu.", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                scope.launch {
                                    aiLoading = true
                                    rawAdviceResult = null
                                    try {
                                        rawAdviceResult = GeminiSpiritualAdvisor.getAdvice(userQuestion)
                                    } catch (e: Exception) {
                                        rawAdviceResult = GeminiSpiritualAdvisor.getRandomFallbackQuote()
                                    } finally {
                                        aiLoading = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicAmber),
                            modifier = Modifier.fillMaxWidth().testTag("ask_mursyid_button"),
                            enabled = !aiLoading
                        ) {
                            Icon(Icons.Outlined.Psychology, contentDescription = null, tint = EmeraldDarkBackground)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("DAPATKAN BIMBINGAN HIKMAH", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Advice output box
                if (aiLoading) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = IslamicAmber)
                            Text(
                                "Mursyid AI sedang merenungi qolbu dan menimba kalam para hikmah ulama tasawuf...",
                                color = SoftGray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                if (rawAdviceResult != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(width = 2.dp, color = IslamicGold, shape = RoundedCornerShape(24.dp))
                            .testTag("ai_advice_card")
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "NASIHAT RUHANI MURSYID",
                                    color = IslamicGold,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 2.sp,
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Icon(Icons.Default.VolunteerActivism, contentDescription = null, tint = IslamicGold, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = rawAdviceResult ?: "",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    lineHeight = 22.sp,
                                    fontStyle = FontStyle.Normal,
                                    color = SoftWhite
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Bimbingan spiritual ini diselaraskan melalui Mursyid AI generasi mutakhir.",
                                style = MaterialTheme.typography.labelSmall.copy(color = SoftGray.copy(alpha = 0.5f)),
                                fontStyle = FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }
    }
}
