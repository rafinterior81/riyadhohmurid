package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DzikirEntity
import com.example.ui.SalikViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DzikirScreen(viewModel: SalikViewModel) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0 = Dzikir Harian, 1 = Pagi & Petang, 2 = Wirid Tarekat, 3 = Tasbih Digital
    val dzikirList by viewModel.dzikirList.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    val filteredList = when (activeTab) {
        0 -> dzikirList.filter { it.category == "Harian" }
        1 -> dzikirList.filter { it.category == "Pagi" || it.category == "Petang" }
        2 -> dzikirList.filter { it.category == "Wirid" }
        else -> emptyList()
    }

    Scaffold(
        floatingActionButton = {
            if (activeTab != 3) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = EmeraldPrimary,
                    contentColor = EmeraldDarkBackground,
                    modifier = Modifier.testTag("add_dzikir_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Dzikir")
                }
            }
        },
        containerColor = EmeraldDarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Scrollable Category Tabs selector
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                containerColor = EmeraldDarkBackground,
                contentColor = EmeraldPrimary,
                edgePadding = 12.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                        color = EmeraldPrimary
                    )
                }
            ) {
                val tabs = listOf("Dzikir Harian", "Pagi & Petang", "Wirid Tarekat", "Tasbih Digital")
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (activeTab == index) EmeraldPrimary else SoftGray
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (activeTab == 3) {
                TasbihDigitalPlayground(viewModel)
            } else {
                if (filteredList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Empty",
                                tint = SoftGray.copy(alpha = 0.5f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Belum ada amalan dzikir di kategori ini.",
                                color = SoftGray,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("dzikir_list"),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filteredList, key = { it.id }) { dzikir ->
                            if (dzikir.category == "Wirid") {
                                DzikirTarekatItemCard(viewModel, dzikir)
                            } else {
                                DzikirItemCard(viewModel, dzikir)
                            }
                        }
                        item {
                            Spacer(modifier = Modifier.height(80.dp))
                        }
                    }
                }
            }
        }

        // Add Dzikir Dialog
        if (showAddDialog) {
            var dzikirName by remember { mutableStateOf("") }
            var dzikirTarget by remember { mutableStateOf("100") }
            var dzikirCategory by remember { mutableStateOf(if (activeTab == 2) "Wirid" else if (activeTab == 1) "Pagi" else "Harian") }
            var dzikirWirid by remember { mutableStateOf("") }
            var dzikirBacaan by remember { mutableStateOf("") }
            var dzikirKeterangan by remember { mutableStateOf("") }
            var dzikirTarekat by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Tambah Amalan Dzikir", color = SoftWhite, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = dzikirName,
                            onValueChange = { dzikirName = it },
                            label = { Text("Nama Amalan Dzikir") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = SoftWhite,
                                unfocusedTextColor = SoftWhite,
                                focusedBorderColor = EmeraldPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("add_dzikir_name")
                        )

                        OutlinedTextField(
                            value = dzikirTarget,
                            onValueChange = { dzikirTarget = it },
                            label = { Text("Target Jumlah") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = SoftWhite,
                                unfocusedTextColor = SoftWhite,
                                focusedBorderColor = EmeraldPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("add_dzikir_target")
                        )

                        Text("Kategori", color = SoftGray, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Harian", "Pagi", "Petang", "Wirid").forEach { cat ->
                                Button(
                                    onClick = { dzikirCategory = cat },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (dzikirCategory == cat) EmeraldPrimary else EmeraldSurfaceCard
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        cat,
                                        color = if (dzikirCategory == cat) EmeraldDarkBackground else SoftWhite,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        if (dzikirCategory == "Wirid") {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Petunjuk & Pedoman Tarekat", color = IslamicAmber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)

                            OutlinedTextField(
                                value = dzikirWirid,
                                onValueChange = { dzikirWirid = it },
                                label = { Text("Nama Wirid (e.g. Hizib Nashor)") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = SoftWhite,
                                    unfocusedTextColor = SoftWhite,
                                    focusedBorderColor = EmeraldPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = dzikirBacaan,
                                onValueChange = { dzikirBacaan = it },
                                label = { Text("Doa & Bacaan Dzikir") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = SoftWhite,
                                    unfocusedTextColor = SoftWhite,
                                    focusedBorderColor = EmeraldPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = dzikirKeterangan,
                                onValueChange = { dzikirKeterangan = it },
                                label = { Text("Keterangan Penggunaan / Pedoman") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = SoftWhite,
                                    unfocusedTextColor = SoftWhite,
                                    focusedBorderColor = EmeraldPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = dzikirTarekat,
                                onValueChange = { dzikirTarekat = it },
                                label = { Text("Dari Aliran Tarekat (e.g. TQN)") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = SoftWhite,
                                    unfocusedTextColor = SoftWhite,
                                    focusedBorderColor = EmeraldPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val targetInt = dzikirTarget.toIntOrNull() ?: 100
                            if (dzikirName.isNotBlank()) {
                                if (dzikirCategory == "Wirid") {
                                    viewModel.addNewDzikir(
                                        name = dzikirName,
                                        category = dzikirCategory,
                                        target = targetInt,
                                        bacaan = dzikirBacaan,
                                        wirid = dzikirWirid,
                                        keterangan = dzikirKeterangan,
                                        tarekat = dzikirTarekat
                                    )
                                } else {
                                    viewModel.addNewDzikir(dzikirName, dzikirCategory, targetInt)
                                }
                                Toast.makeText(context, "Amalan berhasil ditambahkan!", Toast.LENGTH_SHORT).show()
                                showAddDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("Simpan", color = EmeraldDarkBackground, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Batal", color = SoftGray)
                    }
                },
                containerColor = EmeraldSurfaceCard
            )
        }
    }
}

@Composable
fun DzikirItemCard(viewModel: SalikViewModel, dzikir: DzikirEntity) {
    val context = LocalContext.current
    val progressFraction = if (dzikir.target > 0) dzikir.currentCount.toFloat() / dzikir.target else 0f
    
    Card(
        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (dzikir.currentCount >= dzikir.target) IslamicAmber.copy(alpha = 0.4f) else Color.Transparent,
                shape = RoundedCornerShape(24.dp)
            )
            .testTag("dzikir_card_${dzikir.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = dzikir.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Kategori: ${dzikir.category} • Target: ${dzikir.target}",
                        style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
                    )
                }

                IconButton(
                    onClick = {
                        viewModel.deleteDzikir(dzikir.id)
                        Toast.makeText(context, "Amalan dihapus", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Hapus",
                        tint = Color.Red.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { progressFraction.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (dzikir.currentCount >= dzikir.target) IslamicAmber else EmeraldPrimary,
                trackColor = EmeraldDarkBackground
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Count status text
                Text(
                    text = "${dzikir.currentCount} / ${dzikir.target}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = if (dzikir.currentCount >= dzikir.target) IslamicGold else SoftWhite,
                        fontWeight = FontWeight.ExtraBold
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Reset Button
                    IconButton(
                        onClick = { viewModel.resetDzikir(dzikir.id) },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = SoftGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Decrement Button
                    IconButton(
                        onClick = { viewModel.decrementDzikir(dzikir.id, dzikir.currentCount) },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Kurang",
                            tint = SoftGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Increment Tap / Clicker Button (Giant and rewarding)
                    Button(
                        onClick = {
                            viewModel.incrementDzikir(dzikir.id, dzikir.currentCount, dzikir.target)
                            if (dzikir.currentCount + 1 == dzikir.target) {
                                Toast.makeText(context, "🎉 Alhamdulillah! Target dzikir tercapai!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (dzikir.currentCount >= dzikir.target) IslamicAmber else EmeraldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("increment_dzikir_${dzikir.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Tambah",
                            tint = EmeraldDarkBackground,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Tebas",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDarkBackground
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TasbihDigitalPlayground(viewModel: SalikViewModel) {
    val count by viewModel.tasbihCount.collectAsState()
    val target by viewModel.tasbihTarget.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "TASBIH DIGITAL",
            style = MaterialTheme.typography.labelLarge.copy(
                color = IslamicAmber,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Ketuk lingkaran untuk menghitung",
            style = MaterialTheme.typography.bodySmall.copy(color = SoftGray)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Target Select Buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Target:", color = SoftGray, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(end = 4.dp))
            listOf(33, 99, 100, 1000).forEach { item ->
                Button(
                    onClick = { viewModel.setTasbihTarget(item) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (target == item) IslamicAmber else EmeraldSurfaceCard
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        "$item",
                        color = if (target == item) EmeraldDarkBackground else SoftWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Large tapping surface / Ring of Sufi Tasbih
        Box(
            modifier = Modifier
                .size(240.dp)
                .clip(CircleShape)
                .background(EmeraldSurfaceCard)
                .border(2.dp, Brush.linearGradient(listOf(IslamicGold, EmeraldPrimary)), CircleShape)
                .clickable {
                    viewModel.incrementTasbih()
                    if (count + 1 == target) {
                        Toast.makeText(context, "📿 Target tasbih $target kali tercapai!", Toast.LENGTH_SHORT).show()
                    }
                }
                .testTag("tasbih_tap_area"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$count",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontSize = 72.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (count >= target) IslamicGold else SoftWhite
                    )
                )
                Text(
                    text = "TARGET: $target",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = SoftGray,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        // Action Buttons Reset/Mute
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { viewModel.resetTasbih() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "ResetCounter", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Reset", fontWeight = FontWeight.Bold, color = Color.White)
            }

            Button(
                onClick = {
                    Toast.makeText(context, "Getaran click tasbih disimulasikan aktif!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSurfaceCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Vibration, contentDescription = "Haptic Click", tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Getar", fontWeight = FontWeight.SemiBold, color = EmeraldPrimary)
            }
        }
    }
}

@Composable
fun DzikirTarekatItemCard(viewModel: SalikViewModel, dzikir: DzikirEntity) {
    val context = LocalContext.current
    val progressFraction = if (dzikir.target > 0) dzikir.currentCount.toFloat() / dzikir.target else 0f
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = EmeraldSurfaceCard),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (dzikir.currentCount >= dzikir.target) IslamicGold.copy(alpha = 0.6f) else IslamicAmber.copy(alpha = 0.2f),
                shape = RoundedCornerShape(24.dp)
            )
            .clickable { isExpanded = !isExpanded }
            .testTag("dzikir_tarekat_card_${dzikir.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    // Tarekat Badge
                    if (dzikir.tarekat.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = IslamicAmber.copy(alpha = 0.15f),
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = "Tarekat: ${dzikir.tarekat}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = IslamicGold,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = dzikir.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                    )

                    if (dzikir.wirid.isNotBlank()) {
                        Text(
                            text = "Wirid: ${dzikir.wirid}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            viewModel.deleteDzikir(dzikir.id)
                            Toast.makeText(context, "Amalan dihapus", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Hapus",
                            tint = Color.Red.copy(alpha = 0.7f)
                        )
                    }

                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isExpanded) "Sembunyikan detail" else "Tampilkan detail",
                        tint = SoftGray
                    )
                }
            }

            // Expandable Content: Bacaan & Keterangan Penggunaan
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    if (dzikir.bacaan.isNotBlank()) {
                        // Bacaan Box with Arabic style
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(EmeraldDarkBackground.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                .border(0.5.dp, SoftGray.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = dzikir.bacaan,
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        color = SoftWhite,
                                        lineHeight = 40.sp,
                                        textAlign = TextAlign.Right
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Keterangan Penggunaan
                    if (dzikir.keterangan.isNotBlank()) {
                        Text(
                            text = "Pedoman & Keterangan:",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = IslamicGold,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = dzikir.keterangan,
                            style = MaterialTheme.typography.bodyMedium.copy(color = SoftGray),
                            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                        )
                    }
                }
            }

            if (!isExpanded) {
                Spacer(modifier = Modifier.height(8.dp))
                // Friendly hint to expand
                Text(
                    text = "Ketuk kartu untuk panduan bacaan & petunjuk",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = SoftGray.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar
            LinearProgressIndicator(
                progress = { progressFraction.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (dzikir.currentCount >= dzikir.target) IslamicGold else EmeraldPrimary,
                trackColor = EmeraldDarkBackground
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Footer controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${dzikir.currentCount} / ${dzikir.target}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = if (dzikir.currentCount >= dzikir.target) IslamicGold else SoftWhite,
                        fontWeight = FontWeight.ExtraBold
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Reset Button
                    IconButton(
                        onClick = { viewModel.resetDzikir(dzikir.id) },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = SoftGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Decrement Button
                    IconButton(
                        onClick = { viewModel.decrementDzikir(dzikir.id, dzikir.currentCount) },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Kurang",
                            tint = SoftGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Increment Tap clicker
                    Button(
                        onClick = {
                            viewModel.incrementDzikir(dzikir.id, dzikir.currentCount, dzikir.target)
                            if (dzikir.currentCount + 1 == dzikir.target) {
                                Toast.makeText(context, "🎉 Alhamdulillah! Target dzikir tarekat tercapai!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (dzikir.currentCount >= dzikir.target) IslamicGold else EmeraldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("increment_dzikir_${dzikir.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Tambah",
                            tint = EmeraldDarkBackground,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Tebas",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDarkBackground
                            )
                        )
                    }
                }
            }
        }
    }
}
