package com.example.ui

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiSpiritualAdvisor {

    private const val TAG = "GeminiAdvisor"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val fallbackQuotes = listOf(
        "\"Ikhlas itu adalah engkau tidak mencari saksi atas amalanmu selain Allah, dan tidak pula menghendaki pemberi pahala selain Dia.\"\n— Ibnu Atha'illah Al-Iskandari (Al-Hikam)",
        "\"Ketahuilah bahwa nafsu itu bagaikan anak kecil; jika engkau biarkan ia menetek, ia akan terus menetek hingga tumbuh dewasa, namun jika engkau sapih ia, ia pun akan berhenti.\"\n— Imam Al-Ghazali",
        "\"Janganlah kamu mencintai kedudukan duniawi, karena dunia menetap di tanganmu, bukan di hatimu. Letakkanlah dunia di tanganmu, akhirat di hatimu, dan Allah di dalam rahasiamu (Sirr).\"\n— Syeikh Abdul Qadir Al-Jailani",
        "\"Siapa yang menyangka dirinya terbebas dari riya, maka ia justru sedang tenggelam dalam riya yang samar. Bersihkan cermin hatimu dengan istighfar.\"\n— Syeikh Junaid Al-Baghdadi",
        "\"Apabila engkau melihat dirimu condong kepada kemudahan ibadah dan kelezatan munajat, bersyukurlah. Namun jika engkau kering dari rasa khusyuk, sadarilah sedang ada tirai dosa yang menghalangimu.\"\n— Imam Hasan Al-Basri"
    )

    fun getRandomFallbackQuote(): String {
        return fallbackQuotes.random()
    }

    suspend fun getAdvice(userIssue: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "API Key is missing or default placeholder. Using spiritual quote fallback.")
            return@withContext getRandomFallbackQuote()
        }

        val prompt = """
            Anda adalah Syeikh Mursyid (guru pembimbing spiritual Sufi) yang arif, lemah lembut, mendalam, penuh kasih sayang, membimbing para Salik (penempuh jalan ruhani).
            Berikan bimbingan keruhanian yang sangat menyejukkan hati, menyembuhkan penyakit kalbu (hasad, riya, ujub, prasangka buruk), menguatkan taqwa, membangkitkan kerinduan pada Ridha Allah, dan berlandaskan ajaran Tazkiyatun Nafs serta kalam hikmah ulama Sufi klasik (seperti Imam Al-Ghazali, Ibnu Atha'illah, Syeikh Abdul Qadir Al-Jailani).
            Jawab dalam Bahasa Indonesia, sampaikan secara langsung tanpa pengantar administratif bot, ringkas (cukup 1-2 paragraf pendek berbobot), penuh kehangatan kebapakan ruhani.
            
            Unek-unek/keadaan hati salik saat ini: 
            "$userIssue"
        """.trimIndent()

        try {
            // Build direct JSON payload
            val root = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val requestBody = root.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Unsuccessful response from Gemini API: ${response.code} ${response.message}")
                    return@withContext getRandomFallbackQuote()
                }

                val bodyString = response.body?.string() ?: return@withContext getRandomFallbackQuote()
                val jsonResponse = JSONObject(bodyString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", getRandomFallbackQuote())
                        }
                    }
                }
                return@withContext getRandomFallbackQuote()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error calling Gemini API", e)
            return@withContext getRandomFallbackQuote()
        }
    }
}
