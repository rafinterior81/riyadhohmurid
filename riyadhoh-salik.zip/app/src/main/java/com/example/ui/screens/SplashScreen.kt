package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldDarkBackground
import com.example.ui.theme.EmeraldSurfaceCardGradientEnd
import com.example.ui.theme.EmeraldSurfaceCardGradientStart
import com.example.ui.theme.IslamicGold
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2200)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        EmeraldDarkBackground,
                        EmeraldSurfaceCardGradientStart,
                        EmeraldSurfaceCardGradientEnd
                    )
                )
            )
            .testTag("splash_screen_root"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            AnimatedVisibility(
                visible = startAnimation,
                enter = fadeIn(animationSpec = tween(1200))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Beautiful Sufi emblem container
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                            .background(IslamicGold.copy(alpha = 0.12f))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(Brush.radialGradient(
                                    colors = listOf(IslamicGold.copy(alpha = 0.25f), Color.Transparent)
                                )),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Explore,
                                contentDescription = "Suluk Logo",
                                tint = IslamicGold,
                                modifier = Modifier.size(60.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "RIYADHOH SALIK",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = IslamicGold,
                            letterSpacing = 4.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("splash_title")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Aplikasi Pendamping Perjalanan Ruhani",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFFB4D2CD),
                            letterSpacing = 1.2.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(48.dp))

                    Text(
                        text = "Taqarrub Ilallah • Tazkiyatun Nafs • Istiqomah",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = IslamicGold.copy(alpha = 0.7f),
                            letterSpacing = 2.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
