package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.SalikViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SalikAppContainer()
            }
        }
    }
}

@Composable
fun SalikAppContainer(viewModel: SalikViewModel = viewModel()) {
    // Stage controller: 0 = Splash, 1 = Login, 2 = MainApp
    var currentStage by remember { mutableStateOf(0) }

    when (currentStage) {
        0 -> SplashScreen(onSplashFinished = { currentStage = 1 })
        1 -> LoginScreen(onLoginSuccess = { currentStage = 2 })
        2 -> MainNavigationScreen(viewModel)
    }
}

@Composable
fun MainNavigationScreen(viewModel: SalikViewModel) {
    val navIndex by viewModel.currentNavIndex.collectAsState()

    val context = androidx.compose.ui.platform.LocalContext.current

    // Gracefully handle back presses by returning to Home screen, or minimizing the app to background instead of killing/breaking the input channel
    BackHandler(enabled = true) {
        if (navIndex != 0) {
            viewModel.changeNavigation(0)
        } else {
            val activity = context as? ComponentActivity
            activity?.moveTaskToBack(true)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = EmeraldSurfaceCard,
                contentColor = EmeraldPrimary,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("salik_bottom_nav")
            ) {
                // Navigation items matching core tabs: [Home, Suluk, Quran, Riyadhah, Tazkiyah]
                NavigationBarItem(
                    selected = navIndex == 0,
                    onClick = { viewModel.changeNavigation(0) },
                    icon = {
                        Icon(
                            imageVector = if (navIndex == 0) Icons.Default.Home else Icons.Default.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = { Text("Home", color = if (navIndex == 0) EmeraldPrimary else SoftGray) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDarkBackground,
                        selectedTextColor = EmeraldPrimary,
                        unselectedIconColor = SoftGray,
                        unselectedTextColor = SoftGray,
                        indicatorColor = EmeraldPrimary
                    )
                )

                NavigationBarItem(
                    selected = navIndex == 1,
                    onClick = { viewModel.changeNavigation(1) },
                    icon = {
                        Icon(
                            imageVector = if (navIndex == 1) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Suluk"
                        )
                    },
                    label = { Text("Suluk", color = if (navIndex == 1) EmeraldPrimary else SoftGray) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDarkBackground,
                        selectedTextColor = EmeraldPrimary,
                        unselectedIconColor = SoftGray,
                        unselectedTextColor = SoftGray,
                        indicatorColor = EmeraldPrimary
                    )
                )

                NavigationBarItem(
                    selected = navIndex == 2,
                    onClick = { viewModel.changeNavigation(2) },
                    icon = {
                        Icon(
                            imageVector = if (navIndex == 2) Icons.Default.MenuBook else Icons.Default.MenuBook,
                            contentDescription = "Quran"
                        )
                    },
                    label = { Text("Quran", color = if (navIndex == 2) EmeraldPrimary else SoftGray) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDarkBackground,
                        selectedTextColor = EmeraldPrimary,
                        unselectedIconColor = SoftGray,
                        unselectedTextColor = SoftGray,
                        indicatorColor = EmeraldPrimary
                    )
                )

                NavigationBarItem(
                    selected = navIndex == 3,
                    onClick = { viewModel.changeNavigation(3) },
                    icon = {
                        Icon(
                            // Self-improvement replacement if icon missing
                            imageVector = Icons.Default.SelfImprovement,
                            contentDescription = "Riyadhah"
                        )
                    },
                    label = { Text("Riyadhah", color = if (navIndex == 3) EmeraldPrimary else SoftGray) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDarkBackground,
                        selectedTextColor = EmeraldPrimary,
                        unselectedIconColor = SoftGray,
                        unselectedTextColor = SoftGray,
                        indicatorColor = EmeraldPrimary
                    )
                )

                NavigationBarItem(
                    selected = navIndex == 4,
                    onClick = { viewModel.changeNavigation(4) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Spa,
                            contentDescription = "Mursyid"
                        )
                    },
                    label = { Text("Mursyid", color = if (navIndex == 4) EmeraldPrimary else SoftGray) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDarkBackground,
                        selectedTextColor = EmeraldPrimary,
                        unselectedIconColor = SoftGray,
                        unselectedTextColor = SoftGray,
                        indicatorColor = EmeraldPrimary
                    )
                )
            }
        },
        containerColor = EmeraldDarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (navIndex) {
                0 -> HomeScreen(viewModel, onNavigateToSection = { idx -> viewModel.changeNavigation(idx) })
                1 -> DzikirScreen(viewModel)
                2 -> QuranScreen(viewModel)
                3 -> RiyadhahScreen(viewModel)
                4 -> MursyidScreen(viewModel)
            }
        }
    }
}
